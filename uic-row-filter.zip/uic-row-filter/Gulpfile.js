var gulp = require('gulp'),
  requireDir = require('require-dir');

requireDir('build/tasks', {
  recurse: true
});

// Register default task.
gulp.task('default', []);
