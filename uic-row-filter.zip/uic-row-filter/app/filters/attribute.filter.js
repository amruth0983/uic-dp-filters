var angular = require('angular');

angular
.module('uic-row-filter')
.filter('uicrfAttributeFilter', function() {
  return function(section, searchPhrase) {
    return section.filter(function(element) {
      var result = true;

      if (element.values && searchPhrase) {
        result = element.label.toLowerCase()
          .indexOf(searchPhrase.toLowerCase()) > -1;
      }

      return result;
    });
  };
});
