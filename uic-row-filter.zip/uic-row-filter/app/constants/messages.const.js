var angular = require('angular');

angular.module('uic-row-filter')
.constant('uicrfMessages', {
  clear: 'Clear all',
  unblock: 'Unblock all',
  loading: 'Loading...',
  empty: 'No data.',
  search: 'Search',
  ascLabel: 'Sort by A-Z',
  descLabel: 'Sort by Z-A'
});
