var angular = require('angular');

angular
.module('uic-row-filter')
.directive('uicrfValueObject', function() {
  return {
    replace: true,
    restrict: 'A',
    template: require('../templates/uicrf-value-object.tpl.html')
  };
});
