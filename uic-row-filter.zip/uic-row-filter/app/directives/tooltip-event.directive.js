var angular = require('angular'),
  _ = require('lodash');

angular.module('uic-row-filter')
.directive('uicrfTooltipEvent', function() {
  return {
    replace: true,
    restrict: 'A',
    scope: {
      type: '@',
      events: '=',
      payload: '=',
      validation: '='
    },
    link: function(scope, element) {
      /**
       * Fires an event if the validation passes.
       *
       * @param {string} action - action that triggered the event.
       */
      function fireTooltipEvent(action) {
        if (_.isUndefined(scope.validation) || scope.validation) {
          scope.events['tooltip:' + action]({
            element: element.get(0),
            for: scope.type,
            payload: scope.payload
          });
        }
      }

      element
      .on('mouseenter', function() {
        fireTooltipEvent('open');
      })
      .on('mouseleave', function() {
        fireTooltipEvent('close');
      });
    }
  };
});
