var angular = require('angular'),
  _ = require('lodash');

angular
.module('uic-row-filter')
.directive('uicRowFilter', function() {
  return {
    scope: {
      config: '=?',
      api: '=?',
      events: '=?'
    },
    template: require('../templates/uic-row-filter.tpl.html'),
    restrict: 'AE',
    replace: true,
    link: function(scope, element) {
      scope.filterAvailable = false;

      scope.api.set('element', element);

      /**
       * Returns whether the clear all button should be
       * disabled.
       *
       * @returns {boolean} - whether clear all is disabled.
       */
      scope.isClearDisabled = function() {
        return scope.config.disableClear &&
          !_.some(scope.config.rowFilterTree, scope.api.hasStoredValue);
      };

      scope.$on('$destroy', function() {
        element.empty();
      });

      scope.$watch('config.searchPhrase', function(value, old) {
        scope.filterAvailable =
          (scope.config.searchPhrase &&
          (scope.config.searchPhrase.length >= scope.config.minFilterLength));

        if (scope.config.searchPhrase &&
          scope.config.searchPhrase.length >=
          scope.config.minFilterLength) {
          if (value && value.trim()) {
            scope.api.expandAll(scope.config.rowFilterTree);
          } else if (!value) {
            scope.api.collapseAll(scope.config.rowFilterTree);
          }
        } else if (old && (_.isUndefined(value) || !scope.filterAvailable)) {
          scope.api.collapseAll(scope.config.rowFilterTree);
        }
      });
    }
  };
});
