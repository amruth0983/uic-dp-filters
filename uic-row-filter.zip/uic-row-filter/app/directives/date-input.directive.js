var angular = require('angular');

angular
.module('uic-row-filter')
.directive('uicrfDateInput', [
  'uicDateRangeApi',
  function(UicDateRangeApi) {
    return {
      replace: true,
      restrict: 'A',
      scope: {
        config: '=',
        events: '='
      },
      template: require('../templates/uicrf-date-input.tpl.html'),
      link: {
        pre: function(scope) {
          scope.events = scope.events || {};
          scope.api = new UicDateRangeApi(scope);
        }
      }
    };
  }
]);
