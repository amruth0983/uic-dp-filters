var angular = require('angular');

angular
.module('uic-row-filter')
.directive('uicrfAttrObject', function() {
  return {
    replace: true,
    restrict: 'A',
    scope: {
      siblings: '=',
      section: '=',
      attribute: '=',
      api: '=',
      config: '=',
      events: '='
    },
    template: require('../templates/uicrf-attr-object.tpl.html')
  };
});
