var angular = require('angular');

angular
.module('uic-row-filter')
.directive('uicrfSectionObject', [
  'RecursionHelper',
  function(RecursionHelper) {
    return {
      restrict: 'A',
      scope: {
        siblings: '=',
        section: '=',
        parent: '=',
        api: '=',
        config: '=',
        events: '='
      },
      template: require('../templates/uicrf-section-object.tpl.html'),
      compile: function(element) {
        return RecursionHelper.compile(element, function() {});
      }
    };
  }
]);
