var angular = require('angular');

angular
.module('uic-row-filter')
.directive('uicrfBranch', function() {
  return {
    replace: true,
    restrict: 'A',
    scope: {
      siblings: '=',
      section: '=',
      parent: '=',
      api: '=',
      config: '=',
      events: '='
    },
    template: require('../templates/uicrf-branch.tpl.html')
  };
});
