var _ = require('lodash'),
  angular = require('angular');

angular
.module('uic-row-filter')
.factory('uicRowFilterApi', ['uicrfMessages', function(messages) {
  /**
   * Component API to be used in angular mode. Methods are part of the
   * constructor because it is necessary to add them to the component
   * directly.
   * @class
   * @param {Object} scope Angular scope of the component to manage its
   * properties.
   */
  function UicRowFilterApi(scope) {
    var values = {},
      _this = this;

    /**
     * Runs the angular digest cycle if it is not already in process.
     */
    function apply() {
      !scope.$root.$$phase && scope.$apply();
    }

    /**
     * Clear attribute values.
     *
     * @param {SectionObject|AttrObject=} section
     *          - section where the attributes should be cleared.
     * @returns {UicRowFilterApi} instance of this component.
     */
    function clearAttrsValues(section) {
      if (!section) {
        _.forEach(scope.config.rowFilterTree, clearAttrsValues);
      } else {
        section.checked = false;

        if (section.values) {
          section.values.forEach(function(value) {
            if (value.checked) {
              value.checked = false;
            }
          });

          if (section.expanded) {
            scope.config.rowFilterAttrValues = angular.copy(section.values);
          }
        } else if (section.children) {
          section.children.forEach(function(child) {
            clearAttrsValues(child);
          });
        }
      }

      return _this;
    }

    /**
     * Unblocks a section and its subsections recursively.
     *
     * @param {SectionObject} section branch to unblock.
     */
    function unblockSection(section) {
      section.blocked = false;

      if (section.children) {
        _.forEach(section.children, function(child) {
          unblockSection(child);
        });
      }
    }

    /**
     * Sets value for a given property.
     * @param {string} property - name of property.
     * @param {*} value - value of property.
     * @return {UicRowFilterApi} instance of this component.
     */
    this.set = function(property, value) {
      values[property] = value;

      return this;
    };

    /**
     * Gets value for a given property.
     * @param {string} property - name of property.
     * @return {*} value of property.
     */
    this.get = function(property) {
      return values[property];
    };

    /**
     * Returns id of this component's scope.
     * @return {number} id of scope
     */
    this.getId = function() {
      return scope.$id;
    };

    /**
     * Updates the configuration of the component.
     * @param {UicRowFilterConfig} config - Configuration object, its
     * properties are defined dynamically.
     * @return {UicRowFilterApi} instance of this component.
     */
    this.updateConfig = function(config) {
      var sameRowFilter = true;

      if (config && config.rowFilterTree) {
        sameRowFilter = _.isEqual(angular.copy(config.rowFilterTree),
          angular.copy(scope.config.rowFilterTree));
      }

      _.merge(scope.config, config, function(destVal, srcVal, key) {
        var value;

        if (key === 'rowFilterTree' && sameRowFilter) {
          value = destVal;
        } else {
          value = srcVal;
        }

        return value;
      });

      if (!sameRowFilter) {
        this.findExpandedSections();
      }

      apply();

      return this;
    };

    /**
     * Initializes the component.
     * @return {UicRowFilterApi} instance of this component.
     */
    this.init = function() {
      this.findExpandedSections();

      apply();

      return this;
    };

    /**
     * Find the first section with expanded set to true and search
     * its inner {SectionObject|AttrObject} looking if there are more sections
     * or attributes expandeds.
     */
    this.findExpandedSections = function() {
      var sectionsToCollapse = [],
        sectionExpanded;

      if (!_.isUndefined(scope.config.rowFilterTree)) {
        _.forEach(scope.config.rowFilterTree, function(section) {
          if (section.expanded && !sectionExpanded) {
            sectionExpanded = section;

            if (section.values) {
              _this.toggleAttributeCollapse(null, section, section);
            } else {
              _this.findExpandedAttribute(section);
            }
          } else if (section.expanded) {
            sectionsToCollapse.push(section);
          }
        });

        _this.collapseAll(sectionsToCollapse);
      }
    };

    /**
     * Find recursively the expanded sections of the tree until
     * it get the leaves (attributes). It will also toggle the other
     * attributes which are not the first one expanded in the same section.
     *
     * @param {SectionObject|AttrObject} item -  one
     * branch of the tree containing an attribute or a subsection.
     */
    this.findExpandedAttribute = function(item) {
      if (item.children && !_.some(item.children, 'values')) {
        _.forEach(item.children, function(child) {
          _this.findExpandedAttribute(child);
        });
      } else if (item.expanded) {
        _.forEach(item.children, function(child) {
          if (child.expanded) {
            child.expanded = false;
            _this.toggleAttributeCollapse(item, item.children, child);
          }
        });
      }
    };

    /**
     * Toggle section collapse.
     *
     * @param {Array.<BranchObject>} siblings - list of siblings.
     * @param {SectionObject} section - section to be collapsed.
     */
    this.toggleSectionCollapse = function(siblings, section) {
      if (!section.blocked) {
        if (section.expanded) {
          this.collapseAll(siblings);
        } else {
          this.collapseAll(siblings, section.name);
        }
      }
    };

    /**
     * Toggle attribute collapse.
     *
     * @param {SectionObject} section - parent section of attribute.
     * @param {Array.<SectionObject|AttrObject>} siblings - list of siblings.
     * @param {AttrObject} attr - attribute to be collapsed.
     */
    this.toggleAttributeCollapse = function(section, siblings, attr) {
      scope.config.rowFilterAttrValues = null;

      if (scope.config.searchPhrase) {
        this.collapseAllAttributes(scope.config.rowFilterTree,
          attr.expanded ? null : attr.name);
      } else {
        this.collapseAll(siblings, attr.name);
      }

      scope.events[attr.expanded ?
        'attribute:expanded' :
        'attribute:collapsed']({
          section: section,
          attr: attr
        });
    };

    /**
     * Handle checkbox change on attribute value. Multi selects attribute in
     * section.
     *
     * @param {SectionObject} section - parent section of attribute.
     * @param {Array.<AttrObject|SectionObject>} siblings - list of siblings.
     * @param {AttrObject} attr
     *          - attribute where the value should be toggled.
     * @param {ValueObject} value - value to be toggled
     * @param {boolean=} silent - whether to run this method without firing
     * events.
     */
    this.toggleAttributeValue = function(section, siblings, attr, value,
        silent) {
      value.checked = !value.checked;

      _.forEach(scope.config.rowFilterAttrValues, function(val) {
        if (val.name === value.name) {
          val.checked = value.checked;
        }
      });

      attr.values = angular.copy(scope.config.rowFilterAttrValues);

      apply();

      if (!silent) {
        scope.events[value.checked ? 'update:value' : 'remove:value']({
          section: section,
          attr: attr,
          value: value
        });
      }
    };

    /**
     * Handle click on attribute name. Single selects value in attribute.
     *
     * @param {SectionObject} section - parent section of attribute.
     * @param {Array.<AttrObject|SectionObject>} siblings - list of siblings.
     * @param {AttrObject} attr
     *          - attribute where the value should be single selected.
     * @param {ValueObject} value - value to be toggled
     */
    this.toggleSingleAttribute = function(section, siblings, attr, value) {
      var someChange = false,
        changedValue;

      _.forEach(scope.config.rowFilterAttrValues, function(sibling) {
        if (sibling.name !== value.name && sibling.checked) {
          sibling.checked = false;
          someChange = true;
        }

        if (sibling.name === value.name) {
          changedValue = sibling;
        }
      });

      changedValue.checked = someChange || !value.checked;
      value.checked = changedValue.checked;

      attr.values = angular.copy(scope.config.rowFilterAttrValues);

      apply();

      scope.events['update:value:single']({
        section: section,
        attr: attr,
        value: value
      });
    };

    /**
     * Checks whether a branch contains some checked value.
     *
     * @param {SectionObject|AttrObject} section - branch to check.
     * @return {boolean} whether this section contains at least one checked
     *   value.
     */
    this.hasStoredValue = function(section) {
      var someStored = false,
        sectionChecked = section.checked || false;

      if (section.children) {
        someStored = _.some(section.children, function(child) {
          return _this.hasStoredValue(child);
        });
      } else {
        someStored = _.some(section.values, function(value) {
          return value.checked;
        });
      }

      return someStored || sectionChecked;
    };

    /**
     * Checks whether a branch contains a blocked subsection.
     *
     * @param {SectionObject} section - branch to check.
     * @return {boolean} whether this section contains at least one blocked
     *   subsection.
     */
    this.hasBlockedSection = function(section) {
      var blockedSection = false;

      if (section.children) {
        blockedSection = _.some(section.children, function(child) {
          return _this.hasBlockedSection(child);
        });
      }

      return blockedSection || section.blocked;
    };

    /**
     * Checks if the whole tree contains at least one blocked section.
     *
     * @return {boolean} if the tree contains at least one blocked section.
     */
    this.hasBlockedSectionsTree = function() {
      return _.some(scope.config.rowFilterTree, function(sect) {
        return _this.hasBlockedSection(sect);
      });
    };

    /**
     * Clears all values in tree.
     */
    this.clearAll = function() {
      clearAttrsValues();
      apply();

      scope.events['remove:all']();
    };

    /**
     * Unblocks a section and its subsections recursively.
     *
     * @param {SectionObject} section branch to unblock.
     */
    this.unblockSection = function(section) {
      unblockSection(section);
      apply();

      scope.events['unblock:section']({
        section: _.cloneDeep(section)
      });
    };

    /**
     * Unblocks all sections in the tree.
     */
    this.unblockAll = function() {
      _.forEach(scope.config.rowFilterTree, function(item) {
        unblockSection(item);
      });
      apply();

      scope.events['unblock:all']();
    };

    /**
     * Clears all values of a section.
     * @param {SectionObject} section - section to clear.
     */
    this.clearSection = function(section) {
      clearAttrsValues(section);
      apply();

      scope.events['remove:section']({
        section: section
      });
    };

    /**
     * Clears all values of an attribute.
     * @param {SectionObject} section - parent section of attribute.
     * @param {AttrObject} attr - attribute to clear.
     */
    this.clearAttribute = function(section, attr) {
      scope.config.expandedAttribute = null;

      clearAttrsValues(attr);
      apply();

      scope.events['remove:attribute']({
        section: section,
        attr: attr
      });
    };

    /**
     * Collapse all opened tree nodes.
     *
     * @param {Array.<SectionObject|AttrObject>} siblings - list of siblings.
     * @param {string} excludeName - skip section/attribute by provided name.
     */
    this.collapseAll = function(siblings, excludeName) {
      if (siblings) {
        _.forEach(siblings, function(el) {
          if (el.name === excludeName) {
            el.expanded = !el.expanded;
          } else {
            el.expanded = false;

            if (el.children) {
              _this.collapseAll(el.children, el.name);
            }
          }
        });
      } else if (scope.config.rowFilterTree) {
        _this.collapseAll(scope.config.rowFilterTree);
      }

      apply();
    };

    /**
     * Collapse all opened attribute branches.
     *
     * @param {Array.<SectionObject|AttrObject>} siblings - list of siblings.
     * @param {string} excludeName - skip attribute by provided name.
     */
    this.collapseAllAttributes = function(siblings, excludeName) {
      _.forEach(siblings, function(el) {
        if (el.values) {
          el.expanded = (el.name === excludeName);
        } else if (el.children) {
          _this.collapseAllAttributes(el.children, excludeName);
        }
      });

      apply();
    };

    this.expandAll = function(siblings) {
      _.forEach(siblings, function(el) {
        if (el.children) {
          el.expanded = true;
          _this.expandAll(el.children);
        }
      });
    };

    /**
     * Triggered if range-slider value was changed (as callback)
     *
     * @param {SectionObject} section - parent section of attribute.
     * @param {AttrObject} attr - attribute where the slider changed.
     * @param {ValueObject} value - value where the slider changed.
     */
    this.sliderChanged = function(section, attr, value) {
      scope.events['update:value']({
        section: section,
        attr: attr,
        value: value
      });
    };

    /**
     * Sets values for an attribute
     * @param {AttrObject} attr attribute to set values
     * @param {Array.<ValueObject>} values values to be set
     */
    this.setAttrValues = function(attr, values) {
      attr.values = values;
      scope.config.rowFilterAttrValues = angular.copy(attr.values);

      apply();
    };

    /**
     * Scrolls the row filter until the branch element related to
     * the given branch id is visible. Search can be performed using
     * branch name or label, in case both are provided, label is used.
     *
     * @param {BranchSearch} searchOptions - search options.
     */
    this.scrollToBranch = function(searchOptions) {
      var tree = this.get('element').find('.row-filter-tree'),
        currentOffset = tree.scrollTop(),
        label, branchElement, branchOffset;

      if (searchOptions.label) {
        label = searchOptions.label;
      } else {
        label = this.findBranch(searchOptions.name).label;
      }

      branchElement = tree.find('.tree-label:contains("' + label + '")');

      if (branchElement.length) {
        branchOffset = branchElement.parent().offset().top -
          tree.offset().top;
        tree.scrollTop(currentOffset + branchOffset);
      }
    };

    /**
     * Finds a branch by id. The search is performed from root to leaves.
     *
     * @param {string} branchName - id of the branch to find.
     * @returns {AttrObject|SectionObject|Object} found branch.
     */
    this.findBranch = function(branchName) {
      var searchBranches = _.clone(scope.config.rowFilterTree),
        branch, searchBranch, index;

      function pushSearchBranch(child) {
        searchBranches.push(child);
      }

      for (index = 0; index < searchBranches.length && !branch; index++) {
        searchBranch = searchBranches[index];

        if (searchBranch.name === branchName) {
          branch = searchBranch;
        }

        if (!branch && searchBranch.expanded && searchBranch.children) {
          searchBranch.children.forEach(pushSearchBranch);
        }
      }

      return branch || {};
    };

    /**
     * Destroys the angular component completely.
     */
    this.destroy = function() {
      scope.$destroy();
    };

    angular.extend(this, scope);

    _.defaultsDeep(scope.config, {
      className: '',
      messages: messages,
      rowFilterAttrValues: null,
      expandedAttribute: null,
      searchPhrase: '',
      blockedIconClass: 'icomoon icomoon-drill-down',
      minFilterLength: 1,
      disableClear: false
    });

    _.defaults(scope.events, {
      'attribute:collapsed': _.noop,
      'attribute:expanded': _.noop,
      'update:value': _.noop,
      'update:value:single': _.noop,
      'remove:all': _.noop,
      'remove:attribute': _.noop,
      'remove:section': _.noop,
      'remove:value': _.noop,
      'unblock:section': _.noop,
      'unblock:all': _.noop,
      'tooltip:open': _.noop,
      'tooltip:close': _.noop
    });
  }

  return UicRowFilterApi;
}]);
