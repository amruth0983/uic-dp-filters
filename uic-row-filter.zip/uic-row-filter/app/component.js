var angular = require('angular');

require('jquery');
require('ui-component');
require('uic-date-range');

require('jquery-ui');
require('angular-recursion');
require('angular-ui-slider');

require('./components/range-slider/range-slider');
require('./components/sort-label/sort-label');

angular.module('uic-row-filter', [
  'uicrf-range-slider',
  'uicrf-sort-label',
  'RecursionHelper',
  'uic-date-range'
]);

require('./constants/messages.const');
require('./directives/attr-object.directive');
require('./directives/branch.directive');
require('./directives/date-input.directive');
require('./directives/section-object.directive');
require('./directives/tooltip-event.directive');
require('./directives/value-object.directive');
require('./directives/uic-row-filter.directive');
require('./filters/attribute.filter');
require('./services/uic-row-filter.api');
