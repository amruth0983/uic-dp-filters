var Component = require('ui-component'),
  _ = require('lodash'),
  angular = require('angular');

require('./component');
require('./styles/style.scss');

/**
 * Constructor for UicRowFilter component.
 *
 * @constructor UicRowFilter
 * @extends UiComponent
 * @class
 * @classdesc The row filter is a simple tree of selectable values that
 * allow displaying or hiding facets.
 * The structure of the tree is:
 * - sections: sections provide nesting, working as branches, so we can group
 * and namespace attributes by some logical relation.
 * - attributes: attributes are leafs, these are filterable from the upper
 * search box of the row filter. Attributes group selectable values.
 * - values: these are the selectable options inside an attribute, they can be
 * of different types: string, number (range-slider) or date (date-range)
 * @param {UicRowFilter#Config} config - Configuration for this component.
 * @copyright adidas GSD 2016 ©
 */
function UicRowFilter(config) {
  var _this = this;

  this.isRendered = false;
  this.isInitialized = false;
  this.config = config || {};
  this.service = null;
  this.element = null;
  this.events = {};

  angular.module('UicRowFilter', ['uic-row-filter'])
    .directive('uicRowFilterWrapper', [
      'uicRowFilterApi',
      function(UicRowFilterApi) {
        return {
          restrict: 'A',
          template:
            '<div data-uic-row-filter ' +
            'data-config="config" ' +
            'data-api="api"' +
            'data-events="events">' +
            '</div>',
          link: {
            pre: function(scope) {
              scope.config = _this.config;
              scope.events = _this.events;
              scope.api = new UicRowFilterApi(scope);

              _this.service = scope.api;
            }
          }
        };
      }]);

  Component.call(this, this.config);
}

UicRowFilter.prototype = _.create(Component.prototype, {});
UicRowFilter.prototype.constructor = UicRowFilter;

/**
 * @typedef BranchSearch
 * @memberOf UicRowFilter#
 * @type {Object}
 * @property {string=} label - label of the branch to search.
 * @property {string=} name - id of the branch to search.
 */

/**
 * @typedef TooltipEvent
 * @memberof UicRowFilter#
 * @type {Object}
 * @property {string} for - id of tooltip type.
 * @property {*} payload - data to send in the event.
 * @property {HTMLElement} element - element that should display a tooltip.
 */

/**
 * @typedef UsageObject
 * @memberof UicRowFilter#
 * @type {Object}
 * @property {boolean} facet - whether this value is a facet.
 * @property {boolean} reference - whether this value is a reference.
 * @property {string} sortBy - sort preference.
 */

/**
 * @typedef ValueObject
 * @memberof UicRowFilter#
 * @type {Object}
 * @property {string} name - name of this value.
 * @property {string} label - label of this value.
 * @property {string} type - the type of this value ("string"|"date"|"integer").
 * @property {number} count - number of elements using this value.
 * @property {boolean} checked - whether this value is selected.
 */

/**
 * @typedef DateObject
 * @extends ValueObject
 * @memberof UicRowFilter#
 * @type {Object}
 * @property {string} name - name of this value.
 * @property {string} label - label of this value.
 * @property {string} type - the type of this value: "date".
 * @property {number} count - number of elements using this value.
 * @property {boolean} checked - whether this value is selected.
 * @property {Object} config - configuration for this date value.
 * @property {string} config.dateFormat - date format expression.
 * @property {string} config.dateStart - start date in valid date expression.
 * @property {string} config.dateEnd - end date in valid date expression.
 */

/**
 * @typedef SliderObject
 * @memberof UicRowFilter#
 * @extends UicRowFilter#ValueObject
 * @type {Object}
 * @property {string} name - name of this value.
 * @property {string} label - label of this value.
 * @property {string} type - the type of this value: "integer".
 * @property {number} count - number of elements using this value.
 * @property {boolean} checked - whether this value is selected.
 * @property {number} min - lower bound for this integer range.
 * @property {number} max - upper bound for this integer range.
 * @property {Array.<number>} selected - selected bounds of range (lower and
 * upper bounds).
 * @property {string} columnXField - x axis property, defaults to x.
 * @property {string} columnYField - y axis property, defaults to y.
 * @property {Array.<{x: number, y: number}>} ranges - data for range slider.
 */

/**
 * @typedef BranchObject
 * @memberof UicRowFilter#
 * @abstract
 * @type {Object}
 * @property {string} name - name of this branch.
 * @property {string} label - label of this branch.
 * @property {boolean=} [checked=false] - whether this branch contains selected
 * values.
 * @property {boolean} expanded - whether this branch is expanded.
 */

/**
 * @typedef SectionObject
 * @memberof UicRowFilter#
 * @extends UicRowFilter#BranchObject
 * @type {Object}
 * @property {string} name - name of this section.
 * @property {string} label - label of this section.
 * @property {boolean=} [checked=false] - whether this section contains selected
 * values.
 * @property {boolean} expanded - whether this section is expanded.
 * @property {Array.<UicRowFilter#BranchObject>} children - list of child
 * branches.
 * @property {boolean} blocked - whether this section is blocked.
 */

/**
 * @typedef AttrObject
 * @memberof UicRowFilter#
 * @extends UicRowFilter#BranchObject
 * @type {Object}
 * @property {string} name - name of this section.
 * @property {string} label - label of this section.
 * @property {boolean=} [checked=false] - whether this attribute contains
 * selected values.
 * @property {boolean} expanded - whether this attribute is expanded.
 * @property {boolean?} [sortable=true] - whether this attribute is sortable.
 * @property {Array.<UicRowFilter#ValueObject>} values - list of child values.
 * @property {UicRowFilter#UsageObject} usage - optional usage object.
 */

/**
 * @typedef Config
 * @memberof UicRowFilter#
 * @type {Object}
 * @property {Element} root - DOM element where append the component.
 * @property {string} name - Name of the component.
 * @property {string} className - CSS class to be appended to the component
 * element.
 * @property {number} [minFilterLength=1] - the minimum characters typed
 * to perform a contain search.
 * @property {Array.<UicRowFilter#BranchObject>} rowFilterTree - list of
 * sections.
 * @property {Array.<UicRowFilter#ValueObject>} rowFilterAttrValues - list of
 * values in expanded attribute.
 * @property {string} expandedAttribute - name of expanded attribute.
 * @property {Object} messages - messages to show in some of the labels of the
 * component.
 * @property {string} searchPhrase - default searchPhrase for filter the
 * attributes.
 * @property {string} blockedIconClass - the icon class name to show when a
 * section is blocked.
 * @example {@lang javascript}
 * {
 *   root: document.createElement('div'),
 *   name: 'Component name',
 *   className: '.class-name',
 *   rowFilterTree: [UicRowFilter#branchObject...],
 *   rowFilterAttrValues: [UicRowFilter#valueObject...],
 *   expandedAttribute: 'section1#attribute1',
 *   searchPhrase: '',
 *   messages: {
 *     clear: 'Clear all', // default
 *     unblock: 'Unblock all', // default
 *     loading: 'Loading...', // default
 *     empty: 'No data.', // default
 *     search: 'Search', // default
 *     ascLabel: 'Sort by A-Z', // default
 *     descLabel: 'Sort by Z-A' // default
 *   },
 *   blockedIconClass: 'icomoon icomoon-drill-down' // default
 * }
 */

/**
 * Event fired when an attribute values are retrieved.
 *
 * @event attribute:expanded
 * @memberof UicRowFilter#
 * @type {Object}
 * @property {UicRowFilter#SectionObject} section - section where the attribute
 * was expanded
 * @property {UicRowFilter#AttrObject} attr - attribute expanded
 */

/**
 * Event fired when an attribute is closed.
 *
 * @event attribute:collapsed
 * @memberof UicRowFilter#
 * @type {Object}
 * @property {UicRowFilter#SectionObject} section - section where the attribute
 * was collapsed.
 * @property {UicRowFilter#AttrObject} attr - attribute collapsed
 */

/**
 * Event fired when an attribute value is updated.
 *
 * @event update:value
 * @memberof UicRowFilter#
 * @type {Object}
 * @property {UicRowFilter#SectionObject} section - section where the value was
 * updated.
 * @property {UicRowFilter#AttrObject} attr - attribute where the value was
 * updated.
 * @property {UicRowFilter#ValueObject|UicRowFilter#SliderObject|
 * UicRowFilter#DateObject} value - value updated.
 */

/**
 * Event fired when a single attribute value is selected, deselecting all other
 * values in the attribute.
 *
 * @event update:value:single
 * @memberof UicRowFilter#
 * @type {Object}
 * @property {UicRowFilter#SectionObject} section - section where the value was
 * updated
 * @property {UicRowFilter#AttrObject} attr - attribute where the value was
 * updated
 * @property {UicRowFilter#ValueObject|UicRowFilter#SliderObject|
 * UicRowFilter#DateObject} value - value updated.
 */

/**
 * Event fired when an attribute value is cleared.
 *
 * @event remove:value
 * @memberof UicRowFilter#
 * @type {Object}
 * @property {UicRowFilter#SectionObject} section - section where the value was
 * cleared
 * @property {UicRowFilter#AttrObject} attr - attribute where the value was
 * cleared
 * @property {UicRowFilter#ValueObject=} value - value cleared
 */

/**
 * Event fired when an attribute is cleared.
 *
 * @event remove:attribute
 * @memberof UicRowFilter#
 * @type {Object}
 * @property {UicRowFilter#SectionObject} section - section where the attribute
 * was cleared
 * @property {UicRowFilter#AttrObject} attr - attribute cleared
 */

/**
 * Event fired when a section is cleared.
 *
 * @event remove:section
 * @memberof UicRowFilter#
 * @type {Object}
 * @property {UicRowFilter#SectionObject} section - section cleared
 */

/**
 * Event fired when a tooltip is opened.
 *
 * @event tooltip:open
 * @type TooltipEvent
 * @memberof UicRowFilter#
 */

/**
 * Event fired when a tooltip is closed.
 *
 * @event tooltip:close
 * @type TooltipEvent
 * @memberof UicRowFilter#
 */

/**
 * Event fired when whole tree is cleared.
 *
 * @event remove:all
 * @memberof UicRowFilter#
 */

/**
 * Event fired when whole tree is unblocked.
 *
 * @event unblock:all
 * @memberof UicRowFilter#
 */

/**
 * Event fired when a section is unblocked.
 *
 * @event unblock:section
 * @memberof UicRowFilter#
 * @type {Object}
 * @property {UicRowFilter#SectionObject} section - section unblocked
 */

/**
 * Renders the component in the root element given via configuration
 * (config.root) if the comonent is not yet rendered.
 *
 * @return {UicRowFilter} instance of this component.
 * @public
 */
UicRowFilter.prototype.render = function() {
  var rootElement;

  if (!this.isRendered) {
    rootElement = angular.element(this.config.root);
    this.element = angular.element('<div data-uic-row-filter-wrapper></div>');

    angular.bootstrap(this.element, ['UicRowFilter']);

    rootElement.append(this.element);

    this.isRendered = true;
  }

  return this;
};

/**
 * Changes component configuration extending the current one with the values of
 * the new one.
 * This should not be used to update the internal tree structure, there are
 * public methods provided for that usage (see setAttrValues).
 *
 * @param {UicRowFilter#Config} config - New configuration for this component.
 * @return {UicRowFilter} instance of this component.
 * @public
 */
UicRowFilter.prototype.updateConfig = function(config) {
  if (this.isRendered) {
    this.service.updateConfig(config);
  } else {
    _.extend(this.config, config);
  }
  return this;
};

/**
 * Initializes logic for this component.
 *
 * @return {UicRowFilter} instance of this component.
 * @public
 */
UicRowFilter.prototype.init = function() {
  if (this.isRendered && !this.isInitialized) {
    this.service.init();

    this.isInitialized = true;
  }

  return this;
};

/**
 * Toggle section collapse.
 *
 * @param {Array.<UicRowFilter#BranchObject>} siblings - list of siblings.
 * @param {UicRowFilter#SectionObject} section - section to be collapsed.
 * @public
 */
UicRowFilter.prototype.toggleSectionCollapse =
  function(siblings, section) {
    this.service.toggleSectionCollapse(siblings, section);
  };

/**
 * Toggle attribute collapse.
 *
 * @fires UicRowFilter#attribute:expanded
 * @fires UicRowFilter#attribute:collapsed
 * @param {UicRowFilter#SectionObject} section - parent section of attribute.
 * @param {Array.<UicRowFilter#BranchObject>} siblings - list of siblings.
 * @param {UicRowFilter#AttrObject} attr - attribute to be collapsed.
 * @public
 */
UicRowFilter.prototype.toggleAttributeCollapse =
  function(section, siblings, attr) {
    this.service.toggleAttributeCollapse(section, siblings, attr);
  };

/**
 * Handle checkbox change on attribute value. Multi selects attribute in
 * section.
 *
 * @fires UicRowFilter#update:value
 * @fires UicRowFilter#remove:value
 * @param {UicRowFilter#SectionObject} section - parent section of attribute.
 * @param {Array.<UicRowFilter#BranchObject>} siblings - list of siblings.
 * @param {UicRowFilter#AttrObject} attr - attribute where the value should be
 * toggled.
 * @param {UicRowFilter#ValueObject} value - value to be toggled.
 * @param {boolean=} silent - whether to run this method without firing
 * events.
 * @public
 */
UicRowFilter.prototype.toggleAttributeValue =
  function(section, siblings, attr, value, silent) {
    this.service.toggleAttributeValue(section, siblings, attr, value, silent);
  };

/**
 * Handle click on attribute name. Single selects value in attribute.
 *
 * @fires UicRowFilter#update:value:single
 * @fires UicRowFilter#remove:value
 * @param {UicRowFilter#SectionObject} section - parent section of attribute.
 * @param {Array.<UicRowFilter#BranchObject>} siblings - list of siblings.
 * @param {UicRowFilter#AttrObject} attr - attribute where the value should be
 * single selected.
 * @param {UicRowFilter#ValueObject} value - value to be toggled
 * @public
 */
UicRowFilter.prototype.toggleSingleAttribute =
  function(section, siblings, attr, value) {
    this.service.toggleSingleAttribute(section, siblings, attr, value);
  };

/**
 * Checks whether a branch contains some checked value.
 *
 * @param {UicRowFilter#BranchObject} section - branch to check.
 * @return {boolean} whether this section contains at least one checked value.
 * @public
 */
UicRowFilter.prototype.hasStoredValue = function(section) {
  return this.service.hasStoredValue(section);
};

/**
 * Clears all values in the tree.
 *
 * @fires UicRowFilter#remove:all
 * @public
 */
UicRowFilter.prototype.clearAll = function() {
  this.service.clearAll();
};

/**
 * Unblocks all sections in the tree.
 *
 * @fires UicRowFilter#unblock:all
 * @public
 */
UicRowFilter.prototype.unblockAll = function() {
  this.service.unblockAll();
};

/**
 * Unblock the section and its subsections.
 *
 * @fires UicRowFilter#unblock:section
 * @param {UicRowFilter#SectionObject} section - section to be unblocked.
 * @public
 */
UicRowFilter.prototype.unblockSection = function(section) {
  this.service.unblockSection(section);
};

/**
 * Clears all values of a section.
 *
 * @fires UicRowFilter#remove:section
 * @param {UicRowFilter#SectionObject} section - section to be cleared.
 * @public
 */
UicRowFilter.prototype.clearSection = function(section) {
  this.service.clearSection(section);
};

/**
 * Clears all values of an attribute.
 *
 * @fires UicRowFilter#remove:attribute
 * @param {UicRowFilter#AttrObject} attr - attribute to be cleared.
 * @public
 */
UicRowFilter.prototype.clearAttribute = function(attr) {
  this.service.clearAttribute(attr);
};

/**
 * Collapse all opened tree nodes.
 *
 * @param {Array.<UicRowFilter#BranchObject>} siblings - list of siblings.
 * @param {string} excludeName - skip section/attribute by provided name.
 * @public
 */
UicRowFilter.prototype.collapseAll = function(siblings, excludeName) {
  this.service.collapseAll(siblings, excludeName);
};

/**
 * Collapse all opened attribute branches.
 *
 * @param {Array.<SectionObject|AttrObject>} siblings - list of siblings.
 * @param {string} excludeName - skip attribute by provided name.
 * @public
 */
UicRowFilter.prototype.collapseAllAttributes = function(siblings, excludeName) {
  this.service.collapseAllAttributes(siblings, excludeName);
};

/**
 * Sets values for an attribute.
 * This should be used to update the internal tree without changing any
 * configuration of the component.
 *
 * @param {UicRowFilter#AttrObject} attr attribute to set values
 * @param {Array.<UicRowFilter#ValueObject>} values values to be set
 * @public
 */
UicRowFilter.prototype.setAttrValues = function(attr, values) {
  this.service.setAttrValues(attr, values);
};

/**
 * Scrolls the row filter until the branch element related to
 * the given branch id is visible. Search can be performed using
 * branch name or label, in case both are provided, label is used.
 *
 * @param {BranchSearch} searchOptions - search options.
 * @returns {UicRowFilter} instance of this component.
 */
UicRowFilter.prototype.scrollToBranch = function(searchOptions) {
  this.service.scrollToBranch(searchOptions);

  return this;
};

/**
 * Adds a listener to an event of this class.
 *
 * @param {string} event - name of the event.
 * @param {function(*)} callback - function to be executed.
 * @return {UicRowFilter} instance of this component.
 * @public
 */
UicRowFilter.prototype.on = function(event, callback) {
  var _this = this;

  Component.prototype.on.call(this, event, callback);

  this.events[event] = function(data) {
    _this.fire(event, data);
  };

  return this;
};

/**
 * Removes a listener to an event of this class.
 *
 * @param {string} event - name of the event.
 * @param {function(*)} callback - function to be removed.
 * @return {UicRowFilter} instance of this component.
 * @public
 */
UicRowFilter.prototype.off = function(event, callback) {
  Component.prototype.off.call(this, event, callback);

  return this;
};

/**
 * Destroys this component.
 * In order to destroy an angular component and being able to re-render it,
 * we have to "unbootstrap" it from the element where the application was
 * started.
 * This requires removing and creating the root element again.
 *
 * @public
 */
UicRowFilter.prototype.destroy = function() {
  if (this.isRendered) {
    this.service.destroy();
    this.element.remove();

    this.service = null;
    this.element = null;
    this.isRendered = false;
    this.isInitialized = false;
  }
};

module.exports = UicRowFilter;
