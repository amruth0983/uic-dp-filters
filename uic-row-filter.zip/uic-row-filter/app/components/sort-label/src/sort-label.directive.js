var angular = require('angular');

angular
  .module('uicrf-sort-label')
  .directive('uicrfSortLabel', sortLabel);

function sortLabel() {
  return {
    controller: 'SortLabelCtrl',
    controllerAs: 'sortLabelCtrl',
    bindToController: {
      sortField: '@',
      source: '=',
      ascLabel: '@',
      descLabel: '@',
      reverse: '@'
    },
    template: require('../../../templates/uicrf-sort-label.tpl.html'),
    restrict: 'AE',
    replace: true,
    scope: {}
  };
}
