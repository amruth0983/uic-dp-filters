var angular = require('angular');

angular
.module('uicrf-sort-label')
.controller('SortLabelCtrl', SortLabelCtrl);

SortLabelCtrl.$inject = ['$scope', '$filter'];

function SortLabelCtrl($scope, $filter) {
  var _this = this,
    sortedSource;

  _this.source = _this.source || null;
  _this.sortField = _this.sortField || 'label';
  _this.reverse = angular.isUndefined(_this.reverse) ? false : _this.reverse;
  _this.ascLabel = _this.ascLabel || 'Sort by A-Z';
  _this.descLabel = _this.descLabel || 'Sort by Z-A';

  _this.sort = sort;
  _this.sortLabelClickHandler = sortLabelClickHandler;

  init();

  function init() {
    $scope.$watch(function() {
      return _this.reverse;
    }, sort);

    $scope.$watch(function() {
      return _this.source;
    }, function(value) {
      if (value !== sortedSource) {
        sort();
      }
    });
  }

  function sort() {
    if (_this.source) {
      sortedSource = _this.source = $filter('orderBy')(_this.source,
        _this.sortField, _this.reverse);
    }
  }

  function sortLabelClickHandler() {
    _this.reverse = !_this.reverse;
  }
}
