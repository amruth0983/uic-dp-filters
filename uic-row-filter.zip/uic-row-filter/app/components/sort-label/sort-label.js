var angular = require('angular');

angular.module('uicrf-sort-label', []);

require('./src/sort-label.controller');
require('./src/sort-label.directive');
