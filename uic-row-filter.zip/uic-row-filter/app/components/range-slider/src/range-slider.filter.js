var angular = require('angular');

angular
.module('uicrf-range-slider')
.filter('uicrfRange', range);

function range() {
  return function(selectedRange, minValue, maxValue) {
    var res = '',
      startValue = selectedRange[0],
      endValue = selectedRange[1],
      allCovered = startValue === minValue && endValue === maxValue;

    // If all range covered display nothing.
    if (!allCovered) {
      if (startValue === minValue) {
        res = 'Under ' + endValue;
      } else if (endValue === maxValue) {
        res = 'Over ' + startValue;
      } else {
        res = startValue + ' - ' + endValue;
      }
    }
    return res;
  };
}
