var angular = require('angular');

angular
  .module('uicrf-range-slider')
  .directive('uicrfRangeInput', RangeInput);

RangeInput.$inject = ['$timeout'];

function RangeInput($timeout) {
  return {
    restrict: 'A',
    replace: true,
    scope: {
      bound: '@',
      model: '=',
      min: '=',
      max: '=',
      step: '@',
      placeholder: '@',
      callback: '=updateCallback'
    },
    template: require('../../../templates/uicrf-range-input.tpl.html'),
    link: {
      pre: function(scope) {
        /**
         * Validates dirty input and sets model.
         */
        function validate() {
          if (scope.value < scope.min) {
            scope.invalid = true;
            scope.value = scope.min;
          } else if (scope.value > scope.max) {
            scope.invalid = true;
            scope.value = scope.max;
          }

          $timeout(function() {
            scope.invalid = false;
          }, 500);

          if (scope.model !== scope.value) {
            scope.model = scope.value;
            scope.callback(scope.bound, scope.model);
          }
        }

        scope.invalid = false;
        scope.value = scope.model;

        scope.onKeyUp = function(event) {
          if (event.keyCode === 13) {
            validate();
          }
        };

        scope.onBlur = function() {
          validate();
        };

        scope.$watch('model', function(newValue, oldValue) {
          if (scope.value !== newValue && newValue !== oldValue) {
            scope.value = newValue;
          }
        });
      }
    }
  };
}
