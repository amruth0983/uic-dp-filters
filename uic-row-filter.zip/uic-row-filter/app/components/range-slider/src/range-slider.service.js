var angular = require('angular');

angular.module('uicrf-range-slider')
.factory('uicrfRangeSliderFactory', rangeSliderFactory);

rangeSliderFactory.$inject = ['$timeout'];

function rangeSliderFactory($timeout) {
  return {
    getCallLater: function() {
      return new CallLaterService();
    },
    createDrawer: function(canvas) {
      return new Drawer(canvas);
    }
  };

  /**
   * Service to manage delay.
   */
  function CallLaterService() {
    var _this = this;

    this.INVALIDATE_DELAY = 150;

    /**
     * Default invalidation type.
     *
     * For instance during slide or resize
     * we will trigger callback constantly each 150 ms.
     *
     * @type {number}
     */
    this.INVALIDATE_TYPE_CONSTANT = 1;

    /**
     * Will invalidate only once.
     *
     * For instance during slide or resize
     * we will trigger callback only once after 150ms idle.
     *
     * @type {number}
     */
    this.INVALIDATE_TYPE_POSTPONED = 2;

    this.invalidatePromise = null;
    this.pendingValues = [];
    this.callback = null;
    this.callbackContext = null;

    this.resetTimeout = resetTimeout;
    this.callLater = callLater;
    this.invalidateType = this.INVALIDATE_TYPE_CONSTANT;

    /**
     * Invoke function with delay, if call is already in queue
     * just updates pending/dirty values.
     *
     * @param {function} callback Callback function.
     * @param {Object} callbackContext Callback scope.
     * @param {Array.<*>} args Arguments to the callback.
     * @returns {Promise} Promise to invalidate callback.
     */
    function callLater(callback, callbackContext, args) {
      _this.pendingValues = args;
      _this.callback = callback;
      _this.callbackContext = callbackContext;

      invalidate();

      return _this.invalidatePromise;
    }

    /**
     * Trigger timer if not active yet to postpone execution
     */
    function invalidate() {
      if (_this.invalidateType === _this.INVALIDATE_TYPE_POSTPONED) {
        if (_this.invalidatePromise) {
          $timeout.cancel(_this.invalidatePromise);
        }
        _this.invalidatePromise = $timeout(commit, _this.INVALIDATE_DELAY);
      } else if (_this.invalidateType === _this.INVALIDATE_TYPE_CONSTANT &&
          !_this.invalidatePromise) {
        _this.invalidatePromise = $timeout(commit, _this.INVALIDATE_DELAY);
      }
    }

    /**
     * Execute callback
     */
    function commit() {
      resetTimeout();
      _this.callback.apply(_this.callbackContext, _this.pendingValues);
      _this.pendingValues = null;
    }

    /**
     * Reset timer related data
     */
    function resetTimeout() {
      if (_this.invalidatePromise) {
        $timeout.cancel(_this.invalidatePromise);
        _this.invalidatePromise = null;
      }
    }
  }

  function Drawer(canvas) {
    var _this = this,
      maxY = 0;

    _this.columns = [];
    _this.canvas = canvas;
    _this.ctx = _this.canvas.getContext('2d');

    _this.columnColor1 = 'rgb(0,0,0)';
    _this.columnColor2 = 'rgb(255,255,255)';
    _this.outOfRangeColumnColor = 'rgb(196,196,196)';

    _this.setColumns = setColumns;
    _this.setOptions = setOptions;
    _this.drawColumns = drawColumns;
    _this.getStep = getStep;

    function setOptions(options) {
      _this.options = options;
    }

    function setColumns(columns) {
      _this.columns = columns;
      calculateMaxY();
    }

    function drawColumns() {
      clearCanvas();

      _this.canvas.width = _this.canvas.offsetWidth;

      _this.columns.forEach(function(column) {
        drawColumn(column);
      });
    }

    function drawColumn(column) {
      var rangeFrom = _this.options.range[0],
        rangeTo = _this.options.range[1],
        colXValue = getColumnXValue(column),
        fillGradient, columnHeight, columnWidth, columnX, columnY;

      if (colXValue >= rangeFrom && colXValue <= rangeTo) {
        fillGradient = _this.ctx.createLinearGradient(0, 0, 0, 170);
        fillGradient.addColorStop(0, _this.columnColor1);
        fillGradient.addColorStop(1, _this.columnColor2);
        _this.ctx.fillStyle = fillGradient;
      } else {
        _this.ctx.fillStyle = _this.outOfRangeColumnColor;
      }

      columnHeight = calculateColumnHeight(column);
      columnWidth = calculateColumnWidth();

      columnY = _this.canvas.height - columnHeight;
      columnX = calculateColumnX(column);

      _this.ctx.fillRect(columnX, columnY, columnWidth, columnHeight);
    }

    function calculateColumnX(column) {
      var totalWidth = _this.canvas.width;

      function valueToX(val) {
        return val * totalWidth /
          (_this.options.maxX - _this.options.minX + 1);
      }

      return Math.round(valueToX(getColumnXValue(column)) -
        valueToX(_this.options.minX));
    }

    function calculateColumnWidth() {
      var columnGap = 2;

      return _this.canvas.width / _this.columns.length - columnGap;
    }

    function getStep() {
      var max = _this.options ? _this.options.maxX : 0,
        min = _this.options ? _this.options.minX : 0;

      return Math.round((max - min) / _this.columns.length);
    }

    function calculateColumnHeight(column) {
      var yValue = getColumnYValue(column);

      return yValue / maxY * _this.canvas.height;
    }

    function clearCanvas() {
      _this.ctx.clearRect(0, 0, _this.canvas.width, _this.canvas.height);
    }

    function getColumnYValue(column) {
      return column[_this.options.columnYField];
    }

    function getColumnXValue(column) {
      return column[_this.options.columnXField];
    }

    function calculateMaxY() {
      _this.columns.forEach(function(column) {
        var colYValue = getColumnYValue(column);

        if (colYValue > maxY) {
          maxY = colYValue;
        }
      });
    }
  }
}
