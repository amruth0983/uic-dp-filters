var angular = require('angular');

angular
.module('uicrf-range-slider')
.directive('uicrfRangeSlider', RangeSlider);

function RangeSlider() {
  return {
    link: linkFunction,
    controller: 'RangeSliderCtrl',
    controllerAs: 'rangeSliderCtrl',
    scope: {
      label: '=',
      count: '=',
      checked: '=',
      columns: '=?',
      selectedRange: '=?',
      minValue: '=?',
      maxValue: '=?',
      columnXField: '@?',
      columnYField: '@?',
      checkboxCall: '=',
      checkboxCallArgs: '=',
      rangeChangeCall: '=',
      rangeChangeCallArgs: '='
    },
    template: require('../../../templates/uicrf-range-slider.tpl.html'),
    restrict: 'A',
    replace: true,
    bindToController: true
  };

  function linkFunction(scope, element, attr, ctrl) {
    var drawer = element.find('.drawer').get(0);

    ctrl.setupDrawer(drawer);
  }
}
