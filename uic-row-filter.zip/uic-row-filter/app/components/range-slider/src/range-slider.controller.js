var jQuery = require('jquery'),
  angular = require('angular');

angular
.module('uicrf-range-slider')
.controller('RangeSliderCtrl', RangeSliderCtrl);

RangeSliderCtrl.$inject = ['$scope', '$window', 'uicrfRangeSliderFactory'];

function RangeSliderCtrl($scope, $window, rangeSliderFactory) {
  var _this = this,
    refreshCallLaterService = null,
    drawer = null;

  _this.minValue = _this.minValue || 0;
  _this.maxValue = _this.maxValue || 100;
  _this.selectedRange = _this.selectedRange || [_this.minValue,
    _this.maxValue];
  _this.columnXField = _this.columnXField || 'colX';
  _this.columnYField = _this.columnYField || 'colY';
  _this.columns = _this.columns || [];
  _this.rangeChangeCall = _this.rangeChangeCall || null;
  _this.rangeChangeCallArgs = _this.rangeChangeCallArgs || [];
  _this.checkboxChangeCall = _this.checkboxChangeCall || null;
  _this.checkboxChangeCallArgs = _this.checkboxChangeCallArgs || [];

  _this.setupDrawer = setupDrawer;
  _this.getStep = getStep;
  _this.onRangeChange = onRangeChange;
  _this.onCheckboxChange = onCheckboxChange;
  _this.sliderOptions = {
    range: true,
    stop: onRangeChange
  };

  refreshCallLaterService = rangeSliderFactory.getCallLater();

  jQuery($window).on('resize', redrawColumns);

  $scope.$watchGroup(
    [
      function() {
        return _this.minValue;
      },
      function() {
        return _this.maxValue;
      },
      function() {
        return _this.columns.length;
      },
      function() {
        return _this.selectedRange[0];
      },
      function() {
        return _this.selectedRange[1];
      }
    ],
    function() {
      refreshCallLaterService.callLater(redrawColumns, _this);
    }
  );

  $scope.$on('$destroy', function() {
    refreshCallLaterService.resetTimeout();
    jQuery($window).off('resize', redrawColumns);
  });

  function setupDrawer(canvas) {
    drawer = rangeSliderFactory.createDrawer(canvas);
  }

  function redrawColumns() {
    if (drawer && _this.columns.length > 0) {
      drawer.setOptions(getDrawerOptions());
      drawer.setColumns(_this.columns);
      drawer.drawColumns();
    }
  }

  function getDrawerOptions() {
    return {
      range: _this.selectedRange,
      minX: parseInt(_this.minValue, 10),
      maxX: parseInt(_this.maxValue, 10),
      columnXField: _this.columnXField,
      columnYField: _this.columnYField
    };
  }

  function getStep() {
    return drawer ? drawer.getStep() : 0;
  }

  /**
   * Called when one of the boundary inputs is modified.
   *
   * @param {string} bound - bound that has been modified.
   * @param {number} value - new value for bound to be set.
   */
  function onRangeChange(bound, value) {
    if (bound === 'lower') {
      _this.selectedRange[0] = value;
    } else if (bound === 'upper') {
      _this.selectedRange[1] = value;
    }

    if (_this.rangeChangeCall) {
      _this.rangeChangeCall.apply(_this, _this.rangeChangeCallArgs);
    }
  }

  function onCheckboxChange() {
    if (_this.checkboxChangeCall) {
      _this.checkboxChangeCall.apply(_this, _this.checkboxChangeCallArgs);
    }
  }
}
