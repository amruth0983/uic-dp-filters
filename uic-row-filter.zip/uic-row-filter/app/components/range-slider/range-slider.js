var angular = require('angular');

angular.module('uicrf-range-slider', ['ui.slider']);

require('./src/range-input.directive');
require('./src/range-slider.controller');
require('./src/range-slider.directive');
require('./src/range-slider.filter');
require('./src/range-slider.service');
