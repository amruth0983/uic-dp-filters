## 2.5.3

- Added Jenkinsfile.

## 2.5.2

- Fixed sonar LCOV path.

## 2.5.1

- Changed dependency management policy.
- Updated list-versions.
- Fixed Date dependency.
- Fixed angular and jquery plugin dependencies.

# 2.5.0

- Integrated eslint-config-gsd.
- Integrated UicDateRange with UicDatePicker.
- Updated styles.
- Updated eslint configurations.
- Updated build-tool.
- Removed bootstrap dependency.

## 2.4.5

- Fixed missing require statements for external modules.
- Removed unnecessary legacy code.

## 2.4.4

- Fixed webpack external modules.

## 2.4.3

- Fixed issue when updating configuration.
- Removed no longer needed dependencies.
- Removed webpack and karma old configurations.
- Replaced NPM scripts by build-tool library tasks:
    - ``build``.
    - ``clean``.
    - ``doc``.
    - ``lint``.
    - ``test`` & ``test:coverage``.

## 2.4.2

- Fixed issue with changes of rowFilterTree structure.

## 2.4.1

- Fixed blurred effect on canvas integer range.
- Removed unnecessary z-index properties.

# 2.4.0

- Added scroll to branch method.
- Updated documentation.
- Updated tests.

## 2.3.15

- Added em to paddings and borders.
- Reverted CSS units to em.

## 2.3.14

- Updated CSS em units to rem.

## 2.3.13

- Added browser test NPM scripts.
- Updated CSS units to em.

## 2.3.12

- Fixed collapse all after find expanded section.

## 2.3.11

- Fixed tooltip enter event.

## 2.3.10

- Added optional disable clear when no filters are aplied.
- Added start npm script.

## 2.3.9

- Updated styles according to the new style guide.
- Updated phantomjs dependency.
- Fixed sass build task.
- Used 'adihaus-regular' as font-family.

## 2.3.8

- Fixed issue with branch caret on Sarafi browser.

## 2.3.7

- Fixed configurable loading and empty messages.

## 2.3.6

- Removed IE clear on search.

## 2.3.5

- Added events tests.
- Added namespace to avoid collisions.
- Updated tests to use ES6 syntax.
- Refactored toggleSingleAttribute() and toggleAttributeValue() methods.
- Moved interface tests to use flows.

## 2.3.4

- Added interface functional tests.
- Fixed spelling in 'minFilterLength' property.
- Removed unused param 'parent' from .toggleSectionCollapse() method.

## 2.3.3

- Added test utils.
- Added flows for functional testing.
- Added functional tests reporter.
- Updated functional tests config.
- Fixed collapse all API method.

## 2.3.2

- Applied changes from v2.2.12

## 2.3.1

- Rename 'tooltip' directive to 'tooltip-event'.

# 2.3.0

- Added functional testing.
- Added build config file for tasks.
- Refactored tasks.
- Updated README.

## 2.2.12

- Fixed null check on rowFilterAttrValues
- Fixed call to findExpandedSection in updateConfig when the rowFilterTree is not updated

## 2.2.11

- Updated condition to hide count.
- Updated example.
- Updated branding-resources.

## 2.2.10

- Updated events documentation.

## 2.2.9

- Fixed toggle value binding.

## 2.2.8

- Added event 'update:value:single'
- Updated event naming:
    - 'updated' -\> 'update:value'
    - 'attributeCollapsed' -\> 'attribute:collapsed'
    - 'attributeExpanded' -\> 'attribute:expanded'
- Fixed single value behavior.

## 2.2.7

- Replaced ng-scrollbar dependency by default scrollbar.

## 2.2.6

- Updated pointer on attribute values.
- Refactored clear all function.
- Fixed event firing for unblock all sections.
- Removed deprecated styles.

## 2.2.5

- Fixed sort to not update internal data structure.

## 2.2.4

- Fixed cursor on blocked section.
- Fixed click event on caret.

## 2.2.3

- Added separator type.
- Updated documentation.

## 2.2.2

- Updated documentation.
- Updated histogram view.

## 2.2.1

- Fix problem when the label is too large.

# 2.2.0

- Added deep dive / blocked sections
- Added sass build task
- Updated build tasks
- Updated styles
- Upgraded date range dependency
- Moved from CSS to SASS

## 2.1.2

- Added tooltip event for sections and attributes.
- Updated styles.
- Updated examples.

## 2.1.1

- Revert cloneDeep from events

# 2.1.0

- Allowed attributes to be non sortable
- Allowed values to not display label, checkbox and count if label is empty

## 2.0.13

- Updated events to clone data structures
- Fixed update of selected range with inputs

## 2.0.12

- Added minimum characters typed to perform a contain search

## 2.0.11

- Fixed bug when selecting attributes or sections as expanded

## 2.0.10

- Removed bower in post install

## 2.0.9

- Upgrade uic-date-range
- Fix jquery require statement
- Fix issue with attributes not collapsing after search

## 2.0.8

- Fix issue when articles do not have a unique id

## 2.0.7

- Fix issue with multiple attributes expanded at the same time.

## 2.0.6

- Fix assingment issue

## 2.0.5

- Fix clear all issue

## 2.0.4

- Resolve icon class collusion

## 2.0.3

- Allow checked sections and attributes
- Fix sonar issues

## 2.0.2

- Add sonar support
- Update documentation
- Ignore UMD exports statements

## 2.0.1

- Fix linter and test task
- Fix icons

# 2.0.0

- Added jsdoc task
- Added tests
- Updated documentation
- Updated build tasks
- Updated to latest version of generator
- Renamed uic-row-filter.js to component.js
- Removed index.js

## 1.5.3

- Fixed histogram view
- Fixed range-slider update event
- Updated example with slider data
- Updated README
    - DateObject
    - SliderObject

## 1.5.2

- Display integer range inline
- Update uic-date-range to 1.2.2

## 1.5.1

- Added wrapper task for module loaders or browser
- Added isInitialized

# 1.5.0

- Moved dependencies to NPM
- Moved type to values
- Update example
- Update left and right padding
- Upgrade uic-date-range to 1.2.0

## 1.4.8

- Update sections and attributes to include parent section.
- Update events with section property:
    - attributeExpanded
    - attributeCollapsed
    - updated
    - remove:value
    - remove:attribute
- Update interface
- Update templates and directives
- Update README

## 1.4.7

- Fix main script
- Upgrade uic-date-range dependency

## 1.4.6

- Fixed single select behavior.

## 1.4.5

- Removed scrollbar content delay.

## 1.4.4

- Update range slider to validate inputs.

## 1.4.3

- Update attribute selection:
    - Single select on click attribute name
    - Multi select on click attribute checkbox

## 1.4.2

- Added versions task
- Added shared object and methods
- Moved dependencies to NPM
- Update README
- Update example
- Update bower directory
- Update pre-link function
- Update style
- Update build tasks
- Removed assets
- Removed example from README

## 1.4.1

- Fix search to be case insensitive

# 1.4.0

- Update search to expand all sections
- Added range slider checkbox
- Fixed int values style

## 1.3.10

- Range slider events:
    - On blur
    - On enter
- Added directive for inputs

## 1.3.9

- Update destroy function

## 1.3.8

- Fixed slider style

## 1.3.7

- Added events:
    - remove:all
    - remove:section
    - remove:attribute
    - remove:value
- General refactor
- Update templates
- Update example
- Update README

## 1.3.6

- Added collapse attribute facet
- Update README
- Update example

## 1.3.5

- Added support for dates with uic-date-range

## 1.3.4

- Remove deprecated code in unblockSection function

## 1.3.3

- Fixed blocked sections
- Fixed collapse all children on collapse expanded section

## 1.3.2

- Added unchecked value event: removed

## 1.3.1

- Improved fetch attr values
- Fixed sort label messages defaults
- Upgrade ui-component dependency

# 1.3.0

- Added index.js file to easily import module
- Added messages to configuration and constants
- Added dependencies through require or global object (window)
- Wrap subcomponent js files in iife
- Update template for loading and empty messages
- Update build tasks to include index.js in dist
- Update README

## 1.2.4

- Removed window assignment

## 1.2.3

- Upgraded library availability through module loaders
- Updated README
- Added amd and commonjs to .eslintrc

## 1.2.2

- Fix font extension

## 1.2.1

- Fixed code style
- Fixed updateConfig()

# 1.2.0

- Upgraded component to use generic data structures
    - Root attributes
    - Multiple nested sections/attributes
    - Added angular-recursion
    - Moved hasStoredValue to API function
    - Updated interface
    - Separated row filter sections in templates and directives
- Fixed component height
- Update concat task
- Added helper data structures to example
- Added jquery to .eslintrc
- Update README.md and bower.json with exact dependencies

## 1.1.2

- Fixed fluid CSS

## 1.1.1

- Upgraded dependencies

# 1.1.0

- Dist version on NPM
- Added .npmignore
- Added .editorconfig

## 1.0.1

- Added Changelog
- Extracted CSS dependencies out of component
- Exposed API methods through plain JS interface
- Updated README with
    - Dependencies
    - Data Structures
    - Properties
    - Methods
    - Events
    - CSS
    - Example

# 1.0.0

- First official version of RowFilter available for AngularJS
