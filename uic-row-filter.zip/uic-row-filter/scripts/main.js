(function(window, SectionObject, AttrObject, ValueObject) {
  var RowFilterService = {},
    tree = [];

  tree.push(new AttrObject('topAttribute', 'Top attribute (without section)', [
    new ValueObject('value991', 'Value 991', 'string'),
    new ValueObject('value992', 'Value 992', 'string'),
    new ValueObject('value993', 'Value 993', 'string')
  ], true, false));

  tree.push(new SectionObject('section1', 'Section 1', [
    new SectionObject('section1.1', 'Section 1.1', [
      new AttrObject('attribute1', 'Attribute 1', [
        new ValueObject('value1', 'Value 1', 'string'),
        new ValueObject('value2', 'Value 2', 'string'),
        new ValueObject('value3', 'Value 3', 'string')
      ]),
      new AttrObject('attribute2', 'Attribute 2', [
        new ValueObject('value4', 'Value 4', 'string'),
        new ValueObject('value5', 'Value 5', 'string'),
        new ValueObject('value6', 'Value 6', 'string'),
        new ValueObject('value7', 'Value 7', 'string')
      ])
    ], false, true),
    new SectionObject('section1.2', 'Section 1.2', [
      new AttrObject('attribute3', 'Attribute 3', [
        new ValueObject('value8', 'Value 8', 'string')
      ])
    ])
  ], false, false));

  tree.push({
    name: 'range',
    label: 'Range',
    expanded: false,
    children: [
      {
        name: 'season',
        label: 'Season',
        expanded: false,
        values: [
          {
            name: '2014',
            label: '2014',
            type: 'string',
            checked: false,
            count: 10
          },
          {
            name:  '2015',
            label: '2015',
            type: 'string',
            checked: false,
            count: 10
          },
          {
            name: '2016',
            label: '2016',
            type: 'string',
            checked: false,
            count: 10
          }
        ]
      }
    ]
  });

  tree.push({
    name: 'model',
    label: 'Model',
    expanded: false,
    blocked: true,
    children: [
      {
        name: 'season',
        label: 'Season',
        expanded: false,
        values: [
          {
            name: '2014',
            label: '2014',
            type: 'string',
            checked: true,
            count: 10
          },
          {
            name:  '2015',
            label: '2015',
            type: 'string',
            checked: true,
            count: 10
          },
          {
            name: '2016',
            label: '2016',
            type: 'string',
            checked: false,
            count: 10
          }
        ]
      }
    ]
  });

  tree.push({
    name: 'section2',
    label: 'Section 2',
    expanded: false,
    children: [
      {
        name: 'attribute4',
        label: 'Attribute 4',
        expanded: false,
        values: [
          {
            name: 'value9',
            label: 'Value 9',
            type: 'string',
            checked: false,
            count: 0
          },
          {
            name: 'value10',
            label: 'Value 10',
            type: 'string',
            checked: false,
            count: 0
          }
        ]
      }, {
        name: 'attribute5',
        label: 'Attribute 5',
        expanded: false,
        values: [
          {
            name: 'value11',
            label: 'Value 11',
            type: 'string',
            checked: false,
            count: 0
          }
        ]
      }
    ]
  });

  tree.push(new SectionObject('section3', 'Section 3 (special types)', [
    new AttrObject('attribute16', 'Attribute 16', [
      new ValueObject('value161', 'Value 161', 'string'),
      new ValueObject('value162', 'Value 162', 'string'),
      new ValueObject('value163', 'Value 163', 'string')
    ]),
    {
      label: 'Int attr 1',
      name: 'intAttr',
      expanded: true,
      sortable: false,
      values: [
        {
          type: 'string',
          name: 'somestringvalue',
          label: 'Some String Value 1',
          count: 123,
          checked: false
        }, {
          type: 'string',
          name: 'somestringvalue2',
          label: 'Some String Value 2',
          count: 3,
          checked: false
        }, {
          type: 'string',
          name: 'somestringvalue3',
          label: 'Some string value 3',
          count: 62,
          checked: false
        }, {
          type: 'separator'
        }, {
          name: 'someIntRange',
          label: 'Some integer range',
          type: 'integer',
          checked: false,
          max: 1000,
          min: -1000,
          selected: [-1000, 1000],
          columnXField: 'x',
          columnYField: 'y',
          ranges: [
            {
              x: -1000,
              y: 1000
            }, {
              x: -500,
              y: 500
            }, {
              x: 0,
              y: 50
            }, {
              x: 500,
              y: 0
            }, {
              x: 980,
              y: 700
            }
          ]
        }
      ]
    },
    {
      label: 'Int attr 2',
      name: 'intAttr2',
      sortable: false,
      values: [
        {
          name: 'someIntRange2',
          type: 'integer',
          checked: false,
          max: 500,
          min: -500,
          selected: [-500, 500],
          columnXField: 'x',
          columnYField: 'y',
          ranges: [
            {
              x: -250,
              y: 1000
            }, {
              x: -100,
              y: 500
            }, {
              x: 0,
              y: 50
            }, {
              x: 50,
              y: 0
            }, {
              x: 175,
              y: 700
            }
          ]
        }
      ]
    },
    new AttrObject('attribute18', 'Non sortable', [
      new ValueObject('valueC', 'Value C', 'string'),
      new ValueObject('valueB', 'Value B', 'string'),
      new ValueObject('valueA', 'Value A', 'string')
    ], false, false),
    {
      label: 'date attr',
      name: 'dateAttr',
      sortable: false,
      values: [
        {
          type: 'string',
          name: 'september',
          label: 'September',
          count: 3,
          checked: false
        }, {
          type: 'date',
          label: 'Uic Date Range',
          count: 1000,
          config: {
            dateFormat: 'dd-MM-yyyy'
          },
          events: {
            updated: function(range) {
              log.debug('date range updated', range);
            }
          }
        }
      ]
    },
    new AttrObject('attribute21', 'Attribute 21', [
      new ValueObject('value211', 'Value211', 'string'),
      new ValueObject('value212', 'Value212', 'string'),
      new ValueObject('value213', 'Value213', 'string')
    ]),
    new AttrObject('attribute22', 'Attribute 22', [
      new ValueObject('value221', 'Value221', 'string'),
      new ValueObject('value222', 'Value222', 'string'),
      new ValueObject('value223', 'Value223', 'string')
    ]),
    new AttrObject('attribute23', 'Attribute 23', [
      new ValueObject('value231', 'Value231', 'string'),
      new ValueObject('value232', 'Value232', 'string'),
      new ValueObject('value233', 'Value233', 'string')
    ]),
    new AttrObject('attribute24', 'Attribute 24', [
      new ValueObject('value241', 'Value241', 'string'),
      new ValueObject('value242', 'Value242', 'string'),
      new ValueObject('value243', 'Value243', 'string')
    ]),
    new AttrObject('attribute25', 'Attribute 25', [
      new ValueObject('value251', 'Value251', 'string'),
      new ValueObject('value252', 'Value252', 'string'),
      new ValueObject('value253', 'Value253', 'string')
    ]),
    new AttrObject('attribute26', 'Attribute 26', [
      new ValueObject('value261', 'Value261', 'string'),
      new ValueObject('value262', 'Value262', 'string'),
      new ValueObject('value263', 'Value263', 'string')
    ])
  ], true));

  tree.push(new SectionObject('section4', 'Section 4', [
    new SectionObject('section4.1', 'Section 4.1', [
      new SectionObject('section4.1.1', 'Section 4.1.1', [
        new SectionObject('section4.1.1.1', 'Section 4.1.1.1', [
          new AttrObject('attribute6', 'Attribute 6', [
            new ValueObject('value10', 'Value 10', 'string'),
            new ValueObject('value10', 'Value 10', 'string')
          ]),
          new AttrObject('attribute7', 'Attribute 7', [
            new ValueObject('value10', 'Value 10', 'string'),
            new ValueObject('value10', 'Value 10', 'string')
          ])
        ]),
        new SectionObject('section4.1.1.2', 'Section 4.1.1.2', [
          new AttrObject('attribute8', 'Attribute 8', [
            new ValueObject('value10', 'Value 10', 'string'),
            new ValueObject('value10', 'Value 10', 'string')
          ]),
          new AttrObject('attribute9', 'Attribute 9', [
            new ValueObject('value10', 'Value 10', 'string'),
            new ValueObject('value10', 'Value 10', 'string')
          ]),
          new AttrObject('attribute10', 'Attribute 10', [
            new ValueObject('value10', 'Value 10', 'string'),
            new ValueObject('value10', 'Value 10', 'string')
          ])
        ]),
        new SectionObject('section4.1.1.3', 'Section 4.1.1.3', [
          new SectionObject('section4.1.1.3.1', 'Section 4.1.1.3.1', [
            new AttrObject('attribute11', 'Attribute 11', [
              new ValueObject('value10', 'Value 10', 'string'),
              new ValueObject('value10', 'Value 10', 'string')
            ]),
            new AttrObject('attribute12', 'Attribute 12', [
              new ValueObject('value10', 'Value 10', 'string'),
              new ValueObject('value10', 'Value 10', 'string'),
              new ValueObject('value10', 'Value 10', 'string'),
              new ValueObject('value10', 'Value 10', 'string'),
              new ValueObject('value10', 'Value 10', 'string'),
              new ValueObject('value10', 'Value 10', 'string')
            ])
          ])
        ])
      ]),
      new AttrObject('attribute 13', 'Attribute 13', [
        new ValueObject('value10', 'Value 10', 'string'),
        new ValueObject('value10', 'Value 10', 'string')
      ]),
      new SectionObject('section4.1.2', 'Section 4.1.2', [
        new AttrObject('attribute14', 'Attribute 14', [
          new ValueObject('value10', 'Value 10', 'string')
        ])
      ])
    ]),
    new AttrObject('attribute0', 'Attribute 0', [
      new ValueObject('value02', 'Value 02', 'string'),
      new ValueObject('value01', 'Value 01', 'string')
    ]),
    new SectionObject('section4.2', 'Section 4.2', [
      new AttrObject('attribute15', 'Attribute 15', [
        new ValueObject('value159', 'Value 159', 'string'),
        new ValueObject('value153', 'Value 153', 'string'),
        new ValueObject('value156', 'Value 156', 'string'),
        new ValueObject('value154', 'Value 154', 'string'),
        new ValueObject('value152', 'Value 152', 'string'),
        new ValueObject('value158', 'Value 158', 'string'),
        new ValueObject('value155', 'Value 155', 'string'),
        new ValueObject('value157', 'Value 157', 'string'),
        new ValueObject('value151', 'Value 151', 'string')
      ], false, false)
    ])
  ]));

  tree.push({
    name: 'facet1',
    label: 'Facet 1',
    values: [
      {
        name: 'facetValue1',
        label: 'Value 1',
        type: 'string',
        count: 1
      }, {
        name: 'facetValue2',
        label: 'Value 2',
        type: 'string',
        count: 2
      }, {
        name: 'facetValue3',
        label: 'Value 3',
        type: 'string',
        count: 3
      }
    ]
  });

  tree.push({
    name: 'facet2',
    label: 'Facet 2',
    values: [
      {
        name: 'facetValue1',
        label: 'Value 1',
        type: 'string',
        count: 1
      }, {
        name: 'facetValue2',
        label: 'Value 2',
        type: 'string',
        count: 2
      }, {
        name: 'facetValue3',
        label: 'Value 3',
        type: 'string',
        count: 3
      }
    ]
  });

  tree.push(new AttrObject('facet3', 'Facet 3', [
    {
      name: 'facetValue1',
      label: 'Value 1',
      type: 'string',
      count: 1
    }, {
      name: 'facetValue2',
      label: 'Value 2',
      type: 'string',
      count: 2
    }, {
      name: 'facetValue3',
      label: 'Value 3',
      type: 'string',
      count: 3
    }
  ]));

  tree.push(new AttrObject('facet4', 'Facet 4', [
    {
      name: 'facetValue1',
      label: 'Value 1',
      type: 'string',
      count: 1
    }, {
      name: 'facetValue2',
      label: 'Value 2',
      type: 'string',
      count: 2
    }, {
      name: 'facetValue3',
      label: 'Value 3',
      type: 'string',
      count: 3
    }
  ]));

  RowFilterService.getTree = function() {
    return tree;
  };

  RowFilterService.getValuesForSection = function(section) {
    return section.attr.values;
  };

  window.RowFilterService = RowFilterService;
}(window, window.SectionObject, window.AttrObject, window.ValueObject,
  window.UsageObject));

(function($, RowFilter, rowFilterService, log) {
  var rowFilterContainer = document.getElementById('container'),
    rowFilter = new UicRowFilter({
      root: rowFilterContainer,
      messages: {
        empty: 'Empty.',
        search: 'Filter',
        clear: 'Clear all',
        unblock: 'Unblock all',
        loading: 'Fetching data...'
      },
      blockedIconClass: 'icomoon icomoon-confidential',
      minFilterLength: 3,
      disableClear: true
    });

  rowFilter
  .on('attribute:expanded', function(data) {
    setTimeout(function() {
      rowFilter.setAttrValues(data.attr, rowFilterService.getValuesForSection(data));
    }, 1000);
    log.debug('attribute:expanded', data);
  })
  .on('attribute:collapsed', function(data) {
    log.debug('attribute:collapsed', data);
  })
  .on('update:value', function(data) {
    log.debug('update:value', data);
  })
  .on('update:value:single', function(data) {
    log.debug('update:value:single', data);
  })
  .on('remove:value', function(data) {
    log.debug('remove:value', data);
  })
  .on('remove:attribute', function(data) {
    log.debug('remove:attribute', data);
  })
  .on('remove:section', function(data) {
    log.debug('remove:section', data);
  })
  .on('remove:all', function() {
    log.debug('clear all');
  })
  .on('unblock:section', function(data) {
    log.debug('unblock:section', data);
  })
  .on('unblock:all', function() {
    log.debug('unblock:all');
  })
  .on('tooltip:open', function(data) {
    log.debug('tooltip:open', data);
  })
  .on('tooltip:close', function(data) {
    log.debug('tooltip:close', data);
  })
  .updateConfig({})
  .render()
  .init();

  log.debug('Row filter ready (loading data...)');

  setTimeout(function() {
    rowFilter.updateConfig({
      rowFilterTree: rowFilterService.getTree()
    });
  }, 1000);

  window.component = rowFilter;
}(jQuery, window.UicRowFilter, window.RowFilterService, log));
