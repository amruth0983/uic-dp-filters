(function(window) {
  /**
   * Attribute object which contains values.
   * @param {!string} name - name of this node.
   * @param {!string} label - label of this node.
   * @param {Array.<ValueObject>} values - list of values.
   * @param {boolean?} sortable - optional sortable status.
   * @param {boolean?} expanded - optional expanded status.
   * @param {UsageObject?} usage - optional usage object.
   */
  function AttrObject(name, label, values, sortable, expanded, usage) {
    this.name = name;
    this.label = label;
    this.values = values || [];
    this.sortable = angular.isUndefined(sortable) || sortable;
    this.expanded = expanded || false;

    if (usage) {
      this.usage = usage;
    }
  }

  window.AttrObject = AttrObject;
}(window));
