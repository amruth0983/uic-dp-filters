(function(window) {
  /**
   * Usage object.
   * @param {boolean} facet - whether it is a facet.
   * @param {boolean} reference - whether it is a reference.
   * @param {string} sortBy - value to sort by.
   */
  function UsageObject(facet, reference, sortBy) {
    this.facet = facet;
    this.reference = reference;
    this.sortBy = sortBy;
  }

  window.UsageObject = UsageObject;
}(window));
