(function(window) {
  /**
   * Value object.
   * @param {!string} name - name of this node.
   * @param {!string} label - label of this node.
   * @param {!integer} min
   * @param {!integer} max
   * @param {!Array.<{key: integer, count: integer}>} ranges
   * @param {boolean?} checked - optional checked status.
   */
  function ValueObject(name, label, min, max, ranges, checked) {
    this.name = name;
    this.label = label;
    this.min = min;
    this.max = max;
    this.selected = [this.min, this.max];
    this.checked = checked || false;
    this.ranges = ranges || []
  }

  window.ValueObject = ValueObject;
}(window));
