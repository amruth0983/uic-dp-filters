(function(window) {
  /**
   * Section object, can be nested more than once.
   * @param {!string} name - name of this node.
   * @param {!string} label - label of this node.
   * @param {Array.<BranchObject>=} children - list of children.
   * @param {boolean=} expanded - optional expanded status.
   */
  function SectionObject(name, label, children, expanded, blocked) {
    this.name = name;
    this.label = label;
    this.children = children || [];
    this.expanded = expanded || false;
    this.blocked = blocked || false;
  }

  window.SectionObject = SectionObject;
}(window));
