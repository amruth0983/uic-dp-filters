(function(window) {
  /**
   * Value object.
   * @param {!string} name - name of this node.
   * @param {!string} label - label of this node.
   * @param {!string} type - type of the values in this node.
   * @param {integer?} count - optional count status.
   * @param {boolean?} checked - optional checked status.
   */
  function ValueObject(name, label, type, count, checked) {
    this.name = name;
    this.label = label;
    this.type = type;
    this.count = count || 0;
    this.checked = checked || false;
  }

  window.ValueObject = ValueObject;
}(window));
