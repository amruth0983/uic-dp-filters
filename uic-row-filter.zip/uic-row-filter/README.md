![[TeamCity Build](http://deheremap4686/project.html?projectId=GlobalSoftwareDevelopment_NpmModules_UiComponents_UicRowFilter)](http://deheremap4686/app/rest/builds/buildType:(id:GlobalSoftwareDevelopment_NpmModules_UiComponents_UicRowFilter_BuildTest)/statusIcon)
[![UT Coverage](https://tools.adidas-group.com/sonar/api/badges/measure?key=com.adidas.bwrnpm.uic-row-filter%3Arefs%2Fheads%2Fdevelop&metric=coverage)](https://tools.adidas-group.com/sonar/overview?id=com.adidas.bwrnpm.uic-row-filter%3Arefs%2Fheads%2Fdevelop)
[![Tech Debt Ratio](https://tools.adidas-group.com/sonar/api/badges/measure?key=com.adidas.bwrnpm.uic-row-filter%3Arefs%2Fheads%2Fdevelop&metric=sqale_debt_ratio)](https://tools.adidas-group.com/sonar/overview?id=com.adidas.bwrnpm.uic-row-filter%3Arefs%2Fheads%2Fdevelop)

# adidas UicRowFilter Component

UI Component: row filter

## Description

The row filter is a hierarchy-tree-like component which allows displaying or
hiding values for filtering data.

The structure of the tree is:
  - ``sections``: sections provide nesting, working as branches, so we can group
and namespace attributes by some logical relation.
  - ``attributes``: attributes are leafs, these are filterable from the upper
search box of the row filter. Attributes group selectable values.
Values inside an attribute are sortable by default, if the option
`attribute.sortable` is set to false, then the sort label won't be shown.
  - ``values``: these are the selectable options inside an attribute, they can be
of different types: string, number (range-slider) or date (date-range).
Values by default display a checkbox, label and count to enable the facets, but
they will be removed if the label is empty. Else, if label is provided but count
is lower than 0, the count will be hidden.

### Updating row filter

Initially, only the core structure of the tree needs to be provided, these are
the sections and attributes.
When it comes to updating the tree after an attribute is expanded, this work
should be done with `setAttrValues()` method, which updates component's internal
data structure without modifying the entire configuration of the component.
`updateConfig()` will perform a hard update of the component and it is not
recommended to be used on the fly, all the config and settings for the components
should ideally be static, although it can be used to update some properties.

### Types

#### Value types

The row filter provides support for four types of values:

##### String

The most basic value, just a toggleable item with some label. View example:

```
[ ] value 21
[x] other value
[ ] 452
```

##### Integer

The integer type offers a slider and inputs (lower and upper values),
its limits are the bounds passed in its configuration. It also provides a histogram
with the count of values for every number in the range. The view is not the same
as ``'string'`` type.

For configuration of these values SliderObject is used. It shares common properties
with string values and adds some other properties:

- ``min``: number, the lower bound for the integer range.
- ``max``: number, the upper bound for the integer range.
- ``selected``: array, as a tuple of two values, representing the selected lower and
upper values.
- ``ranges``: an array of objects with two properties, by default `x` and `y`,
representing the list of columns to show in the histogram.
- ``columnXField``: a string to set the `x` coordinate property for objets in `range`
array.
- ``columnYField``: a string to set the `y` coordinate property for objets in `range`
array.

Values in `x` property must be numbers between min - max range, both included.

Example:

A valid slider object could be like:

```js
{
  name: 'fooBarInt',
  label: 'Foo Bar Sample Int Range',
  checked: false,
  type: 'integer',
  min: 1,
  max: 3,
  selected: [2, 2],
  columnXField: 'foo',
  columnYField: 'bar',
  ranges: [
    {
      foo: 1,
      bar: 10
    }, {
      foo: 2,
      bar: 100
    }, {
      foo: 3,
      bar: 50
    }
  ]
}
```

##### Date

A date value shows a date-range [startDate : endDate], where the
user may pick from a calendar the bounds of this range or type them according to
the date format.

For configuration of these values DateObject is used. It shares common properties
with string values and adds a config object with following properties:

- ``dateFormat``: string, the format string used to render dates,
based on [DateJS Guidelines](https://tools.adidas-group.com/confluence/display/DSBP/DateJS)
- ``dateStart``: string, start date to show in the first field.
- ``dateEnd``: string, end date to show in the second field.

##### Separator

A separator for values inside an attribute. In order to work with separators,
the attribute must be **non sortable**.

In order to add a separator simply add a value in the attribute like:

```js
{
  type: 'separator'
}
```

Example:

```js
{
  name: 'Attr',
  sortable: false,
  values: [
    {
      name: 'Value 1',
      type: 'string',
      checked: false
    }, {
      type: 'separator'
    }, {
      name: 'Value 2',
      type: 'string',
      checked: true
    }
  ]
}
```

#### Blocking sections

Via configuration, the row filter can be set to have sections blocked.
Blocked sections cannot be expanded and will be rendered in a darker color with
its caret changed by an icon set in configuration property `blockedIconClass`.

When some section or subsection is marked as blocked, the clear all button will
change its behaviour.

1. If some section or subsection across the tree are marked as blocked: unblock
all sections and subsections without removing their checked values.
2. If no section or subsection across the tree are marked as blocked: clear all
checked values.

This also applies to the clear button at section level.

1. If this section or some subsection across its children are marked as blocked:
unblock this section and all its subsections without removing their checked
values.
2. If neither this section nor any subsection across its children are blocked:
clear all checked values.

To set a section as blocked, the section property `blocked` must be set to true.

#### Expand configuration

Via configuration, the row filter data structure can be set to render with some
expanded section or attribute. In order to do this, the target section/attribute
and all its parent sections must be marked as expanded.

The algorithm that expands after changing the config does the following:

Precondition: row filter tree as the list to be explored.

1. Explores the list and takes the *first* section/attribute marked as expanded.
2. Expands it.
3. If the item is a section, get its children and go to 1.
4. If the item is an attribute, fire expand attribute event and we are done.

##### Example

Let a row filter tree like this:

```
[
  {
    name: 'Section 1',
    expanded: true,
    children: [
      {
        name: 'Attr 1',
        values: []
      }, {
        name: 'Attr 2',
        expanded: true,
        values: []
      }
    ]
  }, {
    name: 'Section 2',
    children: [
      {
        name: 'Attr 1',
        values: []
      }
    ]
  }
]
```

When the row filter gets renderer, it will expand `Section 1/Attr 2/` hence
raising the event of `attributeExpanded`.

If instead the row filter tree was:

```
[
  {
    name: 'Section 1',
    expanded: true,
    children: [
      {
        name: 'Attr 1',
        values: []
      }, {
        name: 'Attr 2',
        values: []
      }
    ]
  }, {
    name: 'Section 2',
    expanded: true,
    children: [
      {
        name: 'Attr 1',
        expanded: true,
        values: []
      }
    ]
  }
]
```

The row filter will expand `Section 1/`, as it was the first child found marked
as expanded.

#### Scroll to visible branch

This feature allows to find a branch currently expanded by name or label. 
If both are provided, label will be used only.

In order to find a branch the algorithm used first looks into the root elements.
If a node matches the name then the search is stopped and the node returned. 
Else, if the node has children, they are added to the end of the search candidates
and will be explored if no matching node is found before.

If the branch subject of search does not exist or is not visible, scroll will not
be performed.

Examples:

```
component.scrollToBranch({
  name: 'section1.attribute3'
});

component.scrollToBranch({
  label: 'Attribute 3'
});
```

#### Tooltip

If a section or attribute contains some checked values, hovering the label of these
sections and branches will fire an event requesting to display a tooltip. Data sent
will be of type `TooltipEvent` with `for: 'appliedFilters'` and in the payload,
the section or attribute element and data structure that was hovered will be available.

## Repository

You may find this component in the following Stash repository [bwrnpm/uic-row-filter](https://tools.adidas-group.com/stash/scm/bwrnpm/uic-row-filter)

## Dependencies

Dependencies of this component may be found in [VERSIONS.txt](VERSIONS.txt) as well
as commit and build information. This file gets autogenerated every build.

This component has dependencies both in bower and npm. Bower dependencies are only
required when we work in a browser environment and should be installed with `bower install`

## Usage

Include the component in your application:

```html
<link href="uic-row-filter/dist/uic-row-filter.css" rel="stylesheet"/>
<script src="uic-row-filter/dist/uic-row-filter.min.js"></script>
```

or if you want to debug:

```html
<script src="uic-row-filter/dist/uic-row-filter.js"></script>
```

### Module loaders

It can also be loaded with require:

```javascript
var UicRowFilter = require('uic-row-filter');
```

### Module wrapper

The component will be wrapped in a module function, using the template which may
be found in [build/templates/wrapper.ejs](build/templates/wrapper.ejs).

Here you should require and make available globally in the scope of the component
any dependencies it may need.

### Plugins

#### uic-date-range

In order to have support for date ranges, uic-date-range must be included in
the project before uic-row-filter.

A date value must be this shape:

```
DateObject extends ValueObject {
  name: string,
  label: string,
  count: number,
  checked: boolean,
  type: 'date',
  config: {
    dateFormat: string,
    dateStart: string,
    dateEnd: string
  }
}
```

## Requirements

This component requires:

- Node installed (required for gulp).
- Bower installed
- gulp installed in order to run tasks.

## Building

Run ```gulp build``` to build both full library and minified version.

Also, if you want to work with the library and have it live built, you can run
```gulp watch```.

## JavaScript

See documentation: `> gulp doc`

## CSS

This component style has been developed from plain CSS, using **uic-row-filter**
as root selector for its style.

## Example

Open the generated ``index.html`` file after running ``npm run build``.

## Testing

### Libraries used:
* **Mocha** test framework ([Documentation](https://mochajs.org/#table-of-contents))
* **Chai** assertion library ([Documentation](http://chaijs.com/api/bdd/))
* **Karma** test runner ([Homepage](http://karma-runner.github.io/0.13/index.html))
* **Sinon** mocks library ([Documentation](http://sinonjs.org/docs/), [Assertion](https://github.com/domenic/sinon-chai))
* **Gulp** task runner ([Documentation](https://github.com/gulpjs/gulp/blob/master/docs/getting-started.md))
* **ESLint** JavaScript linting utility ([Homepage](http://eslint.org/))
* **Loglevel** logging library ([Documentation](https://github.com/pimterry/loglevel#documentation))


### Run the tests

* All tests: `> gulp test`
* Unit test: `> gulp test:unit`
* Functional tests: [Detailed instructions](#running-functional-tests-end-to-end)

### Running functional tests (End to End)

For running functional tests locally, first we will need to install the
protractor package globally.

`> npm install -g protractor`

This will install two command line tools, `protractor` and `webdriver-manager`.

The `webdriver-manager` is a helper tool to easily get an instance of Selenium Server running.
We can download and install the necessary binaries with:

`> webdriver-manager update`

And then, run the server with:

`> webdriver-manager start`

Once we have an instance of the server running we should open a new terminal window
and run our functional tests using the npm task:

`> npm run test:functional`

These tests will run locally, if you want to run them in a remote server, then
pass the flag `--remote`:

`> npm run test:functional -- --remote`

#### Safari

For testing in Safari it will be also necessary to download the driver extension for it.
It can be downloaded in the section **SafariDriver** from the [Selenium Downloads](http://www.seleniumhq.org/download/) page.

To install it you should do double click in the downloaded file and then add it to Safari.

## Other tasks

* Lint all sources (JS, CSS): `> gulp lint`
* Lint JavaScript: `> gulp lint:js`
* Show test coverage: `> gulp test:coverage`
  * Test coverage found in `tests/results/coverage` folder.
* Generate documentation: `> gulp doc`
  * Documentation found in `doc` folder.

## File structure

```
The-Project/
├──app/                    (application source files)
├──build/
│  ├── servers/
│  │   └── integration-server.js   (simple HTTP server for run functional tests)
│  └── tasks/   (gulp tasks stored here)
├── doc/   (Generated documentation)
├── test/      (Test folder)
│   ├── config/   (Test configs)
│   │   ├── karma.conf.js            (Shared config file)
│   │   ├── karma.coverage.conf.js   (for coverage)
│   │   ├── karma.tdd.conf.js        (for test driven development)
│   │   ├── karma.unit.conf.js       (for unit tests)
│   │   └── mocha-globals.js         (initialize globals)
│   ├── specs/   (Test scripts)
│   │   ├── unit/          (Scripts of Unit tests)
│   │   └── integration/   (Scripts of Integration tests)
│   └── results/   (Test results)
│       ├── unit/          (reporter results for unit tests)
│       ├── coverage/      (coverage results in lcov/html formats)
│       └── integration/   (reporter results for integration tests)
├── .bowerrc       (Bower Config)
├── .eslintrc      (ESLint Config)
├── bower.json     (Bower dependencies)
├── Gulpfile.js   (Task runner Config)
├── package.json   (NodeJS dependencies)
└── README.md
```
