/**
 * Matches elements containing some text.
 * @param {string|RegExp} match - text to match.
 * @returns {Array.<HTMLElement>} array of matching elements.
 */
function matchLocator(match) {
  var ignoreRegExp = /DOCUMENT|HTML|BODY|HEAD|META|SCRIPT|STYLE/,
    matches = [];

  /**
   * Adds an element to the matches if it contains the given text.
   * @param {HTMLElement} element - element to analyze.
   */
  function addMatching(element) {
    var i;

    if (!ignoreRegExp.test(element.nodeName) &&
        element.textContent &&
        element.textContent.match(match)) {
      matches.push(element);
    }

    if (element.children) {
      for (i = 0; i < element.children.length; i++) {
        addMatching(element.children[i]);
      }
    }
  }

  addMatching(document);

  return matches;
}

/**
 * Splits the string by whitespaces.
 * @param {string} str - string to be splitted.
 * @param {string|RegExp} [regExp=/\s+/] - string or regular expression.
 * @return {Array.<string>} Different words inside the string.
 */
function splitStr(str, regExp) {
  return str.trim().split(regExp || /\s+/);
}

module.exports = {
  matchLocator: matchLocator,
  splitStr: splitStr
};
