var _ = require('lodash'),
  Promise = require('es6-promise').Promise;

/**
 * Returns branch for given label.
 *
 * @param {string} label - branch label.
 * @returns {ElementFinder} element.
 */
function getBranchFor(label) {
  return element(by.cssContainingText('.tree-label', label));
}

/**
 * Returns value for given label.
 *
 * @param {string} label - value label.
 * @returns {ElementFinder} element.
 */
function getValueFor(label) {
  return element(by.cssContainingText('.label-wrapper', label));
}

/**
 * Returns the checkbox for a value.
 *
 * @param {string} label - value label.
 * @returns {ElementFinder} element.
 */
function getCheckboxFor(label) {
  return element(by.cssContainingText('.label-text', label))
  .element(by.xpath('..'))
  .element(by.css('.label-checkbox'));
}

/**
 * Expand a path recursively. If some branch is already expanded, skip it.
 *
 * @param {Array.<string>} branches - branches to expand.
 * @returns {Promise} promise handler.
 */
function recurseExpand(branches) {
  return new Promise(function(resolve, reject) {
    var label = branches.shift(),
      branch;

    if (branches.length) {
      branch = getBranchFor(label);

      branch.getAttribute('class')
      .then(function(classes) {
        var _classes = classes.split(' '),
          promise;

        if (_.indexOf(_classes, 'expanded') < 0) {
          promise = branch.click();
        } else {
          promise = Promise.resolve();
        }

        return promise;
      })
      .then(function() {
        recurseExpand(branches).then(function() {
          resolve();
        });
      });
    } else {
      getBranchFor(label).click().then(function() {
        resolve();
      });
    }
  });
}

/**
 * Expands a path of branches.
 *
 * @param {Array.<string>|string} branch - branch to expand.
 * @returns {Promise} promise handler.
 */
function clickBranch(branch) {
  return new Promise(function(resolve, reject) {
    var branches;

    if (_.isArray(branch)) {
      branches = branch;
    } else {
      branches = [branch];
    }

    recurseExpand(branches)
    .then(function() {
      resolve();
    });
  });
}

/**
 * Clicks a value checkbox.
 *
 * @param {string} label - value label.
 * @returns {Promise} promise handler.
 */
function clickValueCheckbox(label) {
  return getValueFor(label)
  .element(by.css('.label-checkbox'))
  .click();
}

/**
 * Clicks a value label.
 *
 * @param {string} label - value label.
 * @returns {Promise} promise handler.
 */
function clickValueLabel(label) {
  return getValueFor(label)
  .element(by.css('.label-text'))
  .click();
}

/**
 * Finds a value under some branches and toggles it.
 *
 * @param {Array.<string>|string} branch - branch to expand.
 * @param {string} label - value label.
 * @returns {Promise} promise handler.
 */
function toggleValue(branch, label) {
  return clickBranch(branch)
  .then(function() {
    return clickValueCheckbox(label);
  });
}

/**
 * Finds a value under some branches and single selects it.
 *
 * @param {Array.<string>|string} branch - branch to expand.
 * @param {string} label - value label.
 * @returns {Promise} promise handler.
 */
function toggleSingleValue(branch, label) {
  return clickBranch(branch)
  .then(function() {
    return clickValueLabel(label);
  });
}

/**
 * Clicks global clear button.
 *
 * @returns {Promise} promise handler.
 */
function clearGlobal() {
  return element(by.css('.clear-all'))
  .click();
}

/**
 * Clicks branch clear button.
 *
 * @param {string} label - branch label.
 * @returns {Promise} promise handler.
 */
function clearBranch(label) {
  return getBranchFor(label)
  .element(by.xpath('..'))
  .element(by.css('.action-icon'))
  .click();
}

/**
 * Hovers an element matching given text.
 * @param {string} text - text to hover.
 * @returns {Promise} promise handler.
 */
function hoverText(text) {
  return browser.actions()
  .mouseMove(element(by.cssContainingText('span', text)))
  .perform();
}

/**
 * Sets the search input to some value.
 * @param {string} text - filter text.
 * @return {Promise} promise handler.
 */
function setFilter(text) {
  return element(by.css('.row-filter-search'))
  .sendKeys(text);
}

/**
 * Clears the search input.
 * @return {Promise} promise handler.
 */
function clearFilter() {
  return element(by.css('.search-block .action-icon'))
  .click();
}

module.exports = {
  getBranchFor: getBranchFor,
  getValueFor: getValueFor,
  getCheckboxFor: getCheckboxFor,
  clickBranch: clickBranch,
  clickValueCheckbox: clickValueCheckbox,
  clickValueLabel: clickValueLabel,
  toggleValue: toggleValue,
  toggleSingleValue: toggleSingleValue,
  clearBranch: clearBranch,
  clearGlobal: clearGlobal,
  hoverText: hoverText,
  setFilter: setFilter,
  clearFilter: clearFilter
};
