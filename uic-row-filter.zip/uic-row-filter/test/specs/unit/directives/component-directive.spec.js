var _ = require('lodash'),
  angular = require('angular');

require('../../../../app/interface');

describe('directive: uicRowFilter', function() {
  var element, $scope, sandbox;

  beforeEach(function() {
    window.module('uic-row-filter');
  });

  beforeEach(window.inject(function($rootScope, $compile) {
    var template =
        '<div data-uic-row-filter ' +
            'data-config="config" ' +
            'data-api="api" ' +
            'data-events="events">' +
        '</div>';

    sandbox = sinon.sandbox.create();

    $scope = $rootScope.$new();
    $scope.config = {};
    $scope.api = {
      set: sandbox.spy(),
      collapseAll: _.noop
    };
    $scope.events = {
      selected: sandbox.spy()
    };

    element = angular.element(template);
    $compile(element)($scope);
    $scope.$digest();
  }));

  afterEach(function() {
    sandbox.restore();
  });

  it('should create the uic', function() {
    expect(element).to.be.defined;
  });

  it('should set the element in the api', function() {
    expect($scope.api.set).to.have.been.calledWith('element');
  });

  describe('(destroy)', function() {
    it('should remove the element', function() {
      $scope.$destroy();

      expect(element.children()).to.have.length(0);
    });
  });
});
