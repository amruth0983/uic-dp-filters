var angular = require('angular');

require('../../../app/interface');

describe('component', function() {
  beforeEach(function() {
    window.module('uic-row-filter');
  });

  it('should create the module', function() {
    expect(angular.module('uic-row-filter')).to.be.defined;
  });
});
