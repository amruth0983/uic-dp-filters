var _ = require('lodash'),
  jQuery = require('jquery'),
  angular = require('angular'),
  Component = require('ui-component'),
  UicRowFilter = require('../../../app/interface');

describe('interface', function() {
  var uic, root, sandbox;

  beforeEach(function() {
    window.module('UicRowFilter', 'uic-row-filter');
  });

  beforeEach(function() {
    root = document.createElement('div');
    uic = new UicRowFilter({
      root: root
    });
  });

  beforeEach(function() {
    sandbox = sinon.sandbox.create();
  });

  afterEach(function() {
    sandbox.restore();
  });

  it('should be an instance of \'Component\'', function() {
    var uic = new UicRowFilter();

    expect(uic).to.be.an.instanceOf(Component);
  });

  it('should have the next properties', function() {
    var uic = new UicRowFilter();

    expect(uic).to.have.property('isRendered').that.is.a('boolean');
    expect(uic).to.have.property('isInitialized').that.is.a('boolean');
    expect(uic).to.have.property('config').that.is.an('object');
    expect(uic).to.have.property('service').that.is.null;
    expect(uic).to.have.property('element').that.is.null;
    expect(uic).to.have.property('events').that.is.an('object');
  });

  it('should have the next mandatory methods and properties', function() {
    var uic = new UicRowFilter();

    expect(uic).to.have.property('render').that.is.a('function');
    expect(uic).to.have.property('init').that.is.a('function');
    expect(uic).to.have.property('updateConfig').that.is.a('function');
    expect(uic).to.have.property('destroy').that.is.a('function');
    expect(uic).to.have.property('on').that.is.a('function');
    expect(uic).to.have.property('off').that.is.a('function');
  });

  xit('should have the next public methods', function() {
    var uic = new UicRowFilter();

    expect(uic).to.have.property('dummy').that.is.a('function');
  });

  describe('method', function() {
    describe('.on()', function() {
      beforeEach(function() {
        sandbox.spy(Component.prototype, 'on');
      });

      it('should return the uic instance', function() {
        expect(uic.on('event:name', _.noop)).to.be.equal(uic);
      });

      it('should add the callback to the event listeners using Component ' +
          'interface',
        function() {
          var eventName = 'event:name',
            callback = sandbox.spy();

          uic.on(eventName, callback);

          expect(Component.prototype.on).to.have.been.called;
          expect(uic.events[eventName]).to.be.a('function');
        }
      );

      it('should call the registered callbacks when the event is called ',
        function() {
          var eventName = 'event:name',
            callbacks = [sandbox.spy(), sandbox.spy()],
            data = 'data';

          _.forEach(callbacks, function(callback) {
            uic.on(eventName, callback);
          });

          uic.events[eventName](data);

          _.forEach(callbacks, function(callback) {
            expect(callback).to.have.been.calledOnce.and.to.have.been
              .calledWithExactly(data);
          });
        }
      );
    });

    describe('.off()', function() {
      beforeEach(function() {
        sandbox.spy(Component.prototype, 'off');
      });

      it('should return the uic instance', function() {
        expect(uic.off()).to.be.equal(uic);
      });

      it('should remove the callback to the event listeners using Component ' +
          'interface',
        function() {
          var eventName = 'event:name',
            callback = sandbox.spy();

          uic.on(eventName, callback);
          uic.off(eventName, callback);

          expect(Component.prototype.off).to.have.been.called;

          uic.events[eventName]();

          expect(callback).not.to.have.been.called;
        }
      );
    });

    describe('(before render)', function() {
      describe('.render()', function() {
        beforeEach(function() {
          sandbox.stub(angular, 'bootstrap');
        });

        it('should return the uic instance', function() {
          expect(uic.render()).to.be.equal(uic);
        });

        it('should create the jQuery element instance in the element property',
          function() {
            uic.render();

            expect(uic.element).to.be.an.instanceOf(jQuery);

            expect(angular.bootstrap).to.have.been.calledOnce.and.to.have
              .been.calledWithExactly(uic.element, ['UicRowFilter']);
          }
        );

        it('should create the uic inside the root element', function() {
          uic.render();

          expect(root.children).to.have.length(1);

          expect(angular.bootstrap).to.have.been.calledOnce.and.to.have
            .been.calledWithExactly(uic.element, ['UicRowFilter']);
        });

        it('should set \'isRendered\' property to \'true\' after rendering',
          function() {
            expect(uic.isRendered).to.be.false;

            uic.render();

            expect(uic.isRendered).to.be.true;
          }
        );
      });

      describe('.init()', function() {
        it('should not initialize the uic if it is not rendered', function() {
          uic.init();

          expect(uic.isRendered).to.be.false;
          expect(uic.isInitialized).to.be.false;
        });
      });

      describe('.updateConfig()', function() {
        beforeEach(function() {
          sandbox.spy(_, 'extend');
        });

        it('should extend the current config',
          function() {
            var config = {
              config: 'value'
            };

            uic.updateConfig(config);

            expect(_.extend).to.have.been.calledOnce.and.to.have.been
              .calledWithExactly(uic.config, config);
            expect(uic.config).to.include(config);
          }
        );
      });

      describe('.destroy()', function() {
        it('should not destroy the uic if it is not rendered', function() {
          uic.destroy();

          expect(uic.isRendered).to.be.false;
          expect(uic.isInitialized).to.be.false;
        });
      });
    });

    describe('(after render)', function() {
      beforeEach(function() {
        sandbox.spy(angular, 'bootstrap');

        uic.render();
      });

      describe('.render()', function() {
        it('should not render the element if it is already rendered',
          function() {
            expect(angular.bootstrap).to.have.been.calledOnce;

            uic.render();

            expect(angular.bootstrap).to.have.been.calledOnce;
          }
        );
      });

      describe('.init()', function() {
        beforeEach(function() {
          sandbox.stub(uic.service, 'init');
        });

        it('should return the uic instance', function() {
          expect(uic.init()).to.be.equal(uic);
        });

        it('should initialize the uic by calling the service', function() {
          uic.init();

          expect(uic.service.init).to.have.been.calledOnce;
        });

        it('should set \'isInitialized\' property to \'true\' after ' +
            'initializing',
          function() {
            expect(uic.isInitialized).to.be.false;

            uic.init();

            expect(uic.isInitialized).to.be.true;
          }
        );

        it('should not initialize the element if it is already initialized',
          function() {
            expect(uic.service.init).not.to.have.been.called;

            uic.init();

            expect(uic.service.init).to.have.been.calledOnce;

            uic.init();

            expect(uic.service.init).to.have.been.calledOnce;
          }
        );
      });

      describe('.updateConfig()', function() {
        beforeEach(function() {
          sandbox.stub(uic.service, 'updateConfig');
        });

        it('should return the uic instance', function() {
          expect(uic.updateConfig()).to.be.equal(uic);
        });

        it('should update the uic configuration by calling the service',
          function() {
            var config = {};

            uic.updateConfig(config);

            expect(uic.service.updateConfig).to.have.been.calledOnce.and.to.have
              .been.calledWithExactly(config);
          }
        );
      });

      describe('.destroy()', function() {
        beforeEach(function() {
          sandbox.stub(uic.service, 'destroy');
        });

        it('should return nothing', function() {
          expect(uic.destroy()).to.be.undefined;
        });

        it('should remove the uic from the root and restart the status',
          function() {
            uic.destroy();

            expect(root.children).to.have.length(0);
            expect(uic.isRendered).to.be.false;
            expect(uic.isInitialized).to.be.false;
            expect(uic.element).to.be.null;
            expect(uic.service).to.be.null;
          }
        );
      });
    });
  });
});
