require('../../../../app/interface');

describe('service: uicRowFilterApi', function() {
  var UicRowFilterApi, uicRowFilterApi, $scope, sandbox;

  beforeEach(function() {
    window.module('uic-row-filter');
  });

  beforeEach(window.inject(function($rootScope, _uicRowFilterApi_) {
    sandbox = sinon.sandbox.create();

    $scope = $rootScope.$new();
    $scope.config = {};
    $scope.events = {};

    sandbox.spy($scope, '$apply');

    UicRowFilterApi = _uicRowFilterApi_;
    uicRowFilterApi = new UicRowFilterApi($scope);
  }));

  afterEach(function() {
    sandbox.restore();
  });

  it('should return the \'UicRowFilterApi\' constructor', function() {
    expect(UicRowFilterApi).to.be.a('function');
  });

  it('should create an instance of the \'UicRowFilterApi\'', function() {
    expect(uicRowFilterApi).to.be.an.instanceOf(UicRowFilterApi);
  });

  it('should have the next mandatory methods and properties', function() {
    expect(uicRowFilterApi).to.have.property('get').that.is.a('function');
    expect(uicRowFilterApi).to.have.property('set').that.is.a('function');
    expect(uicRowFilterApi).to.have.property('getId').that.is.a('function');
    expect(uicRowFilterApi).to.have.property('init').that.is.a('function');
    expect(uicRowFilterApi).to.have.property('updateConfig').that.is.a(
      'function');
    expect(uicRowFilterApi).to.have.property('destroy').that.is.a('function');
  });

  it('should have the next public methods', function() {});

  describe('.get()', function() {
    it('should return the property value (previously set)', function() {
      var property = 'property',
        value = 'value';

      uicRowFilterApi.set(property, value);

      expect(uicRowFilterApi.get(property)).to.be.eql(value);
    });
  });

  describe('.set()', function() {
    it('should return the service instance', function() {
      expect(uicRowFilterApi.set('property', 'value')).to.be.equal(
        uicRowFilterApi);
    });

    it('should set the property with its value', function() {
      var property = 'property',
        value = 'value';

      uicRowFilterApi.set(property, value);

      expect(uicRowFilterApi.get(property)).to.be.eql(value);
    });
  });

  describe('.getId()', function() {
    it('should return the \'$id\' property of the scope', function() {
      expect(uicRowFilterApi.getId()).to.be.eql($scope.$id);
    });
  });

  describe('.init()', function() {
    it('should return the service instance', function() {
      expect(uicRowFilterApi.init()).to.be.equal(uicRowFilterApi);
    });
  });

  describe('.updateConfig()', function() {
    it('should return the service instance', function() {
      expect(uicRowFilterApi.updateConfig()).to.be.equal(uicRowFilterApi);
    });

    it('should merge the config with the current scope config', function() {
      var value = 'value',
        config = {
          property: value
        };

      expect($scope.config).not.to.have.property('property');

      uicRowFilterApi.updateConfig(config);

      expect($scope.config).to.have.property('property').that.is.eql(value);
    });
  });

  describe('.findBranch()', function() {
    var tree;

    beforeEach(function() {
      tree = [
        {
          name: 'section1'
        }, {
          name: 'section2',
          children: [
            {
              name: 'attr1'
            }
          ]
        }, {
          name: 'section3',
          children: [
            {
              name: 'attr2'
            }
          ],
          expanded: true
        }
      ];

      uicRowFilterApi.updateConfig({
        rowFilterTree: tree
      });
    });

    it('should find a visible branch', function() {
      var branch = uicRowFilterApi.findBranch('section1');

      expect(branch).to.deep.equal(tree[0]);
    });

    it('should find a visible branch inside an expanded section', function() {
      var branch = uicRowFilterApi.findBranch('attr2');

      expect(branch).to.deep.equal(tree[2].children[0]);
    });

    it('should not find a branch that is not visible', function() {
      var branch = uicRowFilterApi.findBranch('attr1');

      expect(branch).to.be.empty;
    });

    it('should not find an unexisting branch', function() {
      var branch = uicRowFilterApi.findBranch('foobar');

      expect(branch).to.be.empty;
    });
  });

  describe('.destroy()', function() {
    it('should return nothing', function() {
      expect(uicRowFilterApi.destroy()).to.be.undefined;
    });

    it('should destroy the scope', function() {
      uicRowFilterApi.destroy();

      expect($scope.$$destroyed).to.be.true;
    });
  });
});
