describe('Use case: Tree scroll to branch', function() {
  beforeEach(function() {
    return setTestTemplate(__dirname, 'scroll-to-branch.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    })
    .then(() => {
      return browser.executeScript(() => {
        window.component.render();
        window.component.init();
      });
    });
  });

  it('should scroll to the last section by name', function() {
    var branch = flows.getBranchFor('section15-label$');

    return browser.executeScript(() => {
      window.component.scrollToBranch({
        name: 'section15-name$'
      });
    })
    .then(() => {
      return branch.isDisplayed()
      .then((isDisplayed) => {
        expect(isDisplayed).to.be.true;
      });
    });
  });

  it('should scroll to the last section by label', function() {
    var branch = flows.getBranchFor('section15-label$');

    return browser.executeScript(() => {
      window.component.scrollToBranch({
        label: 'section15-label$'
      });
    })
    .then(() => {
      return branch.isDisplayed()
      .then((isDisplayed) => {
        expect(isDisplayed).to.be.true;
      });
    });
  });

  it('should scroll to last section\'s first attribute by name', function() {
    return flows.clickBranch('section15-label$')
    .then(() => {
      return browser.executeScript(() => {
        window.component.scrollToBranch({
          name: 'section14-attr1-name$'
        });
      });
    })
    .then(() => {
      return flows.getBranchFor('section14-attr1-label$').isDisplayed()
      .then((isDisplayed) => {
        expect(isDisplayed).to.be.true;
      });
    });
  });
});
