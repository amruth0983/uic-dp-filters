describe('Use case: Clear all ', function() {
  beforeEach(function() {
    return setTestTemplate(__dirname, 'clear-global.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    })
    .then(() => {
      return browser.executeScript(() => {
        window.component.render();
        window.component.init();
      });
    });
  });

  it('should clear all branches with filters', function() {
    return flows.clearGlobal()
    .then(() => {
      return flows.getBranchFor('section1-label$')
      .element(by.xpath('..'))
      .isElementPresent(by.css('.action-icon'))
      .then((isPresent) => {
        expect(isPresent).to.be.false;
      });
    });
  });
});
