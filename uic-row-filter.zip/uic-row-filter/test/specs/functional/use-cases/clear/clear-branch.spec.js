describe('Use case: Clear branch', function() {
  beforeEach(function() {
    return setTestTemplate(__dirname, 'clear-branch.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    })
    .then(() => {
      return browser.executeScript(() => {
        window.component.render();
        window.component.init();
      });
    });
  });

  it('should clear a branch with filters', function() {
    return flows.clearBranch('section1-label$')
    .then(() => {
      return flows.getBranchFor('section1-label$')
      .element(by.xpath('..'))
      .isElementPresent(by.css('.action-icon'))
      .then((isPresent) => {
        expect(isPresent).to.be.false;
      });
    });
  });
});
