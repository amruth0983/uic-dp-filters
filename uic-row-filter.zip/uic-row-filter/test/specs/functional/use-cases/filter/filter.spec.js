describe('Use case: Filter', function() {
  beforeEach(function() {
    return setTestTemplate(__dirname, 'filter.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    })
    .then(() => {
      return browser.executeScript(() => {
        window.component.render();
        window.component.init();
      });
    });
  });

  describe('set filter', function() {
    it('should filter and find one attribute', function() {
      return flows.setFilter('section1-attr1-label$'.substr(0, 5))
      .then(() => {
        return flows.getBranchFor('section1-attr1-label$')
        .isPresent()
        .then((isPresent) => {
          expect(isPresent).to.be.true;
        });
      });
    });

    it('should filter and hide all attributes', function() {
      return flows.setFilter('non-existing-attr-label$')
      .then(() => {
        return flows.getBranchFor('section1-attr1-label$')
        .isPresent()
        .then((isPresent) => {
          expect(isPresent).to.be.false;
        });
      });
    });
  });

  describe('clear filter', function() {
    beforeEach(function() {
      return flows.setFilter('non-existing-attr-label$');
    });

    it('should clear the filter', function() {
      return flows.clearFilter()
      .then(() => {
        return element(by.css('.row-filter-search'))
        .getText()
        .then((text) => {
          expect(text).to.be.empty;
        });
      });
    });
  });

  describe('min filter length', function() {
    beforeEach(function() {
      return browser.executeScript(() => {
        window.component.updateConfig({
          minFilterLength: 5
        });
      });
    });

    it('should not filter with less than min characters', function() {
      return flows.setFilter('att')
      .then(() => {
        return flows.getBranchFor('section1-attr1-label$')
        .isPresent()
        .then((isPresent) => {
          expect(isPresent).to.be.false;
        });
      });
    });

    it('should filter with equal or more than min characters', function() {
      return flows.setFilter('attr1')
      .then(() => {
        return flows.getBranchFor('section1-attr1-label$')
        .isPresent()
        .then((isPresent) => {
          expect(isPresent).to.be.true;
        });
      });
    });
  });
});
