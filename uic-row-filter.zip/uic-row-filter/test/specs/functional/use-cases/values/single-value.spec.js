describe('Use case: Values', function() {
  beforeEach(function() {
    return setTestTemplate(__dirname, 'single-value.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    })
    .then(() => {
      return browser.executeScript(() => {
        window.component
        .render()
        .init()
        .on('attribute:expanded', function(data) {
          window.component.setAttrValues(data.attr, data.attr.values);
        })
        .updateConfig({
          rowFilterTree: [
            {
              label: 'section1-label$',
              name: 'section1-name$',
              expanded: true,
              children: [
                {
                  label: 'section1-attr1-label$',
                  name: 'section1-attr1-name$',
                  expanded: true,
                  values: [
                    {
                      label: 'section1-attr1-value1-label$',
                      name: 'section1-attr1-value1-name$'
                    }, {
                      label: 'section1-attr1-value2-label$',
                      name: 'section1-attr1-value2-name$'
                    }
                  ]
                }
              ]
            }
          ]
        });
      });
    });
  });

  describe('select value by label', function() {
    it('should select one value', function() {
      return flows.clickValueLabel('section1-attr1-value1-label$')
      .then(() => {
        return flows.getValueFor('section1-attr1-value1-label$')
        .element(by.css('.label-checkbox'))
        .getAttribute('class')
        .then((classes) => {
          expect(classes.split(' ')).to.include('checked');
        });
      })
      .then(() => {
        return flows.getBranchFor('section1-attr1-label$')
        .element(by.xpath('..'))
        .element(by.css('.action-icon'))
        .isPresent()
        .then((isPresent) => {
          expect(isPresent).to.be.true;
        });
      });
    });

    it('should deselect one value', function() {
      return flows.clickValueLabel('section1-attr1-value1-label$')
      .then(() => {
        return flows.clickValueLabel('section1-attr1-value1-label$');
      })
      .then(() => {
        return flows.getValueFor('section1-attr1-value1-label$')
        .element(by.css('.label-checkbox'))
        .getAttribute('class')
        .then((classes) => {
          expect(classes.split(' ')).to.not.include('checked');
        });
      })
      .then(() => {
        return flows.getBranchFor('section1-attr1-label$')
        .element(by.xpath('..'))
        .element(by.css('.action-icon'))
        .isPresent()
        .then((isPresent) => {
          expect(isPresent).to.be.false;
        });
      });
    });

    it('should select only one value', function() {
      return flows.clickValueLabel('section1-attr1-value2-label$')
      .then(() => {
        return flows.clickValueLabel('section1-attr1-value1-label$');
      })
      .then(() => {
        return flows.getValueFor('section1-attr1-value1-label$')
        .element(by.css('.label-checkbox'))
        .getAttribute('class')
        .then((classes) => {
          expect(classes.split(' ')).to.include('checked');
        });
      })
      .then(() => {
        return flows.getValueFor('section1-attr1-value2-label$')
        .element(by.css('.label-checkbox'))
        .getAttribute('class')
        .then((classes) => {
          expect(classes.split(' ')).to.not.include('checked');
        });
      });
    });

    it('should deselect all but one value', function() {
      return flows.clickValueCheckbox('section1-attr1-value1-label$')
      .then(() => {
        return flows.clickValueCheckbox('section1-attr1-value2-label$');
      })
      .then(() => {
        return flows.clickValueLabel('section1-attr1-value1-label$');
      })
      .then(() => {
        return flows.getValueFor('section1-attr1-value1-label$')
        .element(by.css('.label-checkbox'))
        .getAttribute('class')
        .then((classes) => {
          expect(classes.split(' ')).to.include('checked');
        });
      })
      .then(() => {
        return flows.getValueFor('section1-attr1-value2-label$')
        .element(by.css('.label-checkbox'))
        .getAttribute('class')
        .then((classes) => {
          expect(classes.split(' ')).to.not.include('checked');
        });
      });
    });
  });

  describe('expand tree and select value by label', function() {
    beforeEach(function() {
      return flows.clickValueCheckbox('section1-attr1-value1-label$')
      .then(() => {
        return flows.clickValueCheckbox('section1-attr1-value2-label$');
      })
      .then(() => {
        return browser.executeScript(() => {
          window.component.collapseAll();
        });
      });
    });

    it('should expand branches and deselect all but one value', function() {
      return flows.toggleSingleValue(
        ['section1-label$', 'section1-attr1-label$'],
        'section1-attr1-value1-label$'
      )
      .then(() => {
        return flows.getValueFor('section1-attr1-value1-label$')
        .element(by.css('.label-checkbox'))
        .getAttribute('class')
        .then((classes) => {
          expect(classes.split(' ')).to.include('checked');
        });
      });
    });
  });
});
