describe('Use case: Unblock all', function() {
  beforeEach(function() {
    return setTestTemplate(__dirname, 'unblock-all.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    })
    .then(() => {
      return browser.executeScript(() => {
        window.component.render();
        window.component.init();
      });
    });
  });

  it('should clear all blocked branches without clearing filters', function() {
    return flows.clearGlobal()
    .then(() => {
      return flows.getBranchFor('section1-label$')
      .element(by.xpath('..'))
      .isElementPresent(by.css('.action-icon'))
      .then((isPresent) => {
        expect(isPresent).to.be.true;
      });
    });
  });

  it('should clear all blocked branches and then clear their filters',
    function() {
      return flows.clearGlobal()
      .then(() => {
        return flows.clearGlobal();
      })
      .then(() => {
        return flows.getBranchFor('section1-label$')
        .element(by.xpath('..'))
        .isElementPresent(by.css('.action-icon'))
        .then((isPresent) => {
          expect(isPresent).to.be.false;
        });
      });
    }
  );
});
