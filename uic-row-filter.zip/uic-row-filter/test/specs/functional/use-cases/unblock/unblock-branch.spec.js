describe('Use case: Unblock branch', function() {
  beforeEach(function() {
    return setTestTemplate(__dirname, 'unblock-branch.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    })
    .then(() => {
      return browser.executeScript(() => {
        window.component.render();
        window.component.init();
      });
    });
  });

  it('should clear a blocked branch without clearing filters', function() {
    return flows.clearBranch('section1-label$')
    .then(() => {
      return flows.getBranchFor('section1-label$')
      .element(by.xpath('..'))
      .isElementPresent(by.css('.action-icon'))
      .then((isPresent) => {
        expect(isPresent).to.be.true;
      });
    });
  });

  it('should clear a blocked branch and then clear its filters', function() {
    return flows.clearBranch('section1-label$')
    .then(() => {
      return flows.clearBranch('section1-label$');
    })
    .then(() => {
      return flows.getBranchFor('section1-label$')
      .element(by.xpath('..'))
      .isElementPresent(by.css('.action-icon'))
      .then((isPresent) => {
        expect(isPresent).to.be.false;
      });
    });
  });
});
