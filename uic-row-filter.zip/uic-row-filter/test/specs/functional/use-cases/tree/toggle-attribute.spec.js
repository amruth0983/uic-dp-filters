describe('Use case: Tree navigation toggle attribute', function() {
  beforeEach(function() {
    return setTestTemplate(__dirname, 'toggle-attribute.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    })
    .then(() => {
      return browser.executeScript(() => {
        window.component.render();
        window.component.init();
      });
    });
  });

  it('should expand one attribute passed as string', function() {
    return flows.clickBranch('attr1-label$')
    .then(() => {
      var value = flows.getValueFor('attr1-value1-label$');

      return value.isPresent()
      .then((isPresent) => {
        expect(isPresent).to.be.true;
      });
    });
  });

  it('should collapse one attribute passed as string', function() {
    return flows.clickBranch('attr1-label$')
    .then(() => {
      return flows.clickBranch('attr1-label$');
    })
    .then(() => {
      var value = flows.getValueFor('attr1-value1-label$');

      return value.isPresent()
      .then((isPresent) => {
        expect(isPresent).to.be.false;
      });
    });
  });

  it('should expand one attribute passed as an array', function() {
    return flows.clickBranch(['attr1-label$'])
    .then(() => {
      var value = flows.getValueFor('attr1-value1-label$');

      return value.isPresent()
      .then((isPresent) => {
        expect(isPresent).to.be.true;
      });
    });
  });

  it('should collapse one attribute passed as an array', function() {
    return flows.clickBranch(['attr1-label$', 'attr1-label$'])
    .then(() => {
      var value = flows.getBranchFor('attr1-value1-label$');

      return value.isPresent()
      .then((isPresent) => {
        expect(isPresent).to.be.false;
      });
    });
  });
});
