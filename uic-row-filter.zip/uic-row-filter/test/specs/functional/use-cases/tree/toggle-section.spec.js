describe('Use case: Tree navigation toggle section', function() {
  beforeEach(function() {
    return setTestTemplate(__dirname, 'toggle-section.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    })
    .then(() => {
      return browser.executeScript(() => {
        window.component.render();
        window.component.init();
      });
    });
  });

  it('should expand one section passed as string', function() {
    return flows.clickBranch('section1-label$')
    .then(() => {
      var branch = flows.getBranchFor('section1-label$');

      return branch.getAttribute('class')
      .then((classes) => {
        expect(classes.split(' ')).to.include('expanded');
      });
    });
  });

  it('should collapse one section passed as string', function() {
    return flows.clickBranch('section1-label$')
    .then(() => {
      return flows.clickBranch('section1-label$');
    })
    .then(() => {
      var branch = flows.getBranchFor('section1-label$');

      return branch.getAttribute('class')
      .then((classes) => {
        expect(classes.split(' ')).to.not.include('expanded');
      });
    });
  });

  it('should expand one section passed as an array', function() {
    return flows.clickBranch(['section1-label$'])
    .then(() => {
      var branch = flows.getBranchFor('section1-label$');

      return branch.getAttribute('class')
      .then((classes) => {
        expect(classes.split(' ')).to.include('expanded');
      });
    });
  });

  it('should expand and collapse one section passed as an array', function() {
    return flows.clickBranch(['section1-label$', 'section1-label$'])
    .then(() => {
      var branch = flows.getBranchFor('section1-label$');

      return branch.getAttribute('class')
      .then((classes) => {
        expect(classes.split(' ')).to.not.include('expanded');
      });
    });
  });

  it('should expand two sections passed as string', function() {
    return flows.clickBranch('section1-label$')
    .then(() => {
      return flows.clickBranch('section1.1-label$');
    })
    .then(() => {
      var branch = flows.getBranchFor('section1.1-label$');

      return branch.getAttribute('class')
      .then((classes) => {
        expect(classes.split(' ')).to.include('expanded');
      });
    });
  });

  it('should expand two sections passed as array', function() {
    return flows.clickBranch(['section1-label$', 'section1.1-label$'])
    .then(() => {
      var branch = flows.getBranchFor('section1.1-label$');

      return branch.getAttribute('class')
      .then((classes) => {
        expect(classes.split(' ')).to.include('expanded');
      });
    });
  });

  it('should do nothing with already expanded sections', function() {
    return flows.clickBranch('section1-label$')
    .then(() => {
      return flows.clickBranch(['section1-label$', 'section1.1-label$']);
    })
    .then(() => {
      var branch = flows.getBranchFor('section1.1-label$');

      return branch.getAttribute('class')
      .then((classes) => {
        expect(classes.split(' ')).to.include('expanded');
      });
    });
  });
});
