describe('Use case: Tooltip for section checked', function() {
  beforeEach(function() {
    return setTestTemplate(__dirname, 'section-checked-tooltip.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    })
    .then(() => {
      return browser.executeScript(() => {
        window.component.render();
        window.component.init();

        window.tooltipCalled = false;
      });
    });
  });

  it('should hover checked section and fire tooltip', function() {
    return flows.hoverText('section1-label$')
    .then(() => {
      return browser.executeScript(() => {
        return window.tooltipCalled;
      })
      .then((called) => {
        expect(called).to.equal.true;
      });
    });
  });

  it('should hover unchecked section and not fire tooltip', function() {
    return flows.clearGlobal()
    .then(() => {
      return flows.hoverText('section1-label$');
    })
    .then(() => {
      return browser.executeScript(() => {
        return window.tooltipCalled;
      })
      .then((called) => {
        expect(called).to.equal.false;
      });
    });
  });
});
