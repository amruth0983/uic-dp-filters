describe('Event: tooltip', function() {
  var tooltipOpenEvent = 'tooltip:open',
    tooltipCloseEvent = 'tooltip:close',
    uic;

  beforeEach(function() {
    return setTestTemplate(__dirname, 'tooltip.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    })
    .then(() => {
      return browser
      .executeScript(() => {
        window.component.render();
        window.component.init();

        return window.uic;
      });
    })
    .then((_uic_) => {
      uic = _uic_;
    });
  });

  it('should not fire any tooltip if there is no checked values', function() {
    return flows.clickBranch([uic.tree[0].name])
    .then(() => {
      return flows.hoverText(uic.tree[0].name);
    })
    .then(() => {
      return flows.hoverText(uic.tree[0].children[0].name);
    })
    .then(() => {
      return browser
      .executeScript(() => {
        return window.uic.events;
      })
      .then((events) => {
        expect(events).to.have.lengthOf(0);
      });
    });
  });

  describe('tooltip:open', function() {
    it('should fire a tooltip in a section with checked values', function() {
      return flows
      .toggleValue(
        [uic.tree[0].name, uic.tree[0].children[0].name],
        uic.tree[0].children[0].values[0].name
      )
      .then(() => {
        return flows.hoverText(uic.tree[0].name);
      })
      .then(() => {
        return browser
        .executeScript(() => {
          return window.uic.events;
        })
        .then((events) => {
          expect(events).to.have.lengthOf(1);
          expect(events[0].event).to.be.eql(tooltipOpenEvent);
        });
      });
    });

    it('should fire a tooltip in an attribute with checked values', function() {
      return flows
      .toggleValue(
        [uic.tree[0].name, uic.tree[0].children[0].name],
        uic.tree[0].children[0].values[0].name
      )
      .then(() => {
        return flows.hoverText(uic.tree[0].children[0].name);
      })
      .then(() => {
        return browser
        .executeScript(() => {
          return window.uic.events;
        })
        .then((events) => {
          expect(events).to.have.lengthOf(1);
          expect(events[0].event).to.be.eql(tooltipOpenEvent);
        });
      });
    });

    it('should fire tooltips in two sections with checked values', function() {
      return flows
      .toggleValue(
        [uic.tree[0].name, uic.tree[0].children[0].name],
        uic.tree[0].children[0].values[0].name
      )
      .then(() => {
        return flows
        .toggleValue(
          [uic.tree[1].name, uic.tree[1].children[0].name],
          uic.tree[1].children[0].values[0].name
        );
      })
      .then(() => {
        return flows.hoverText(uic.tree[0].name);
      })
      .then(() => {
        return flows.hoverText(uic.tree[1].name);
      })
      .then(() => {
        return browser
        .executeScript(() => {
          return window.uic.events;
        })
        .then((events) => {
          expect(events).to.have.lengthOf(3);
          expect(events[0].event).to.be.eql(tooltipOpenEvent);
          expect(events[2].event).to.be.eql(tooltipOpenEvent);
        });
      });
    });
  });

  describe('tooltip:close', function() {
    it('should fire a tooltip in a section with checked values', function() {
      return flows
      .toggleValue(
        [uic.tree[0].name, uic.tree[0].children[0].name],
        uic.tree[0].children[0].values[0].name
      )
      .then(() => {
        return flows.hoverText(uic.tree[0].name);
      })
      .then(() => {
        return flows.hoverText(uic.tree[1].name);
      })
      .then(() => {
        return browser
        .executeScript(() => {
          return window.uic.events;
        })
        .then((events) => {
          expect(events).to.have.lengthOf(2);
          expect(events[1].event).to.be.eql(tooltipCloseEvent);
        });
      });
    });

    it('should fire a tooltip in an attribute with checked values', function() {
      return flows
      .toggleValue(
        [uic.tree[0].name, uic.tree[0].children[0].name],
        uic.tree[0].children[0].values[0].name
      )
      .then(() => {
        return flows.hoverText(uic.tree[0].children[0].name);
      })
      .then(() => {
        return flows.hoverText(uic.tree[1].name);
      })
      .then(() => {
        return browser
        .executeScript(() => {
          return window.uic.events;
        })
        .then((events) => {
          expect(events).to.have.lengthOf(2);
          expect(events[1].event).to.be.eql(tooltipCloseEvent);
        });
      });
    });

    it('should fire tooltips in two sections with checked values', function() {
      return flows
      .toggleValue(
        [uic.tree[0].name, uic.tree[0].children[0].name],
        uic.tree[0].children[0].values[0].name
      )
      .then(() => {
        return flows
        .toggleValue(
          [uic.tree[1].name, uic.tree[1].children[0].name],
          uic.tree[1].children[0].values[0].name
        );
      })
      .then(() => {
        return flows.hoverText(uic.tree[0].name);
      })
      .then(() => {
        return flows.hoverText(uic.tree[1].name);
      })
      .then(() => {
        return flows.hoverText(uic.tree[0].name);
      })
      .then(() => {
        return browser
        .executeScript(() => {
          return window.uic.events;
        })
        .then((events) => {
          expect(events).to.have.lengthOf(5);
          expect(events[1].event).to.be.eql(tooltipCloseEvent);
          expect(events[3].event).to.be.eql(tooltipCloseEvent);
        });
      });
    });
  });
});
