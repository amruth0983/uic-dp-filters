describe('Event: attribute', function() {
  var expandEvent = 'attribute:expanded',
    collapseEvent = 'attribute:collapsed',
    uic;

  beforeEach(function() {
    return setTestTemplate(__dirname, 'attribute.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    })
    .then(() => {
      return browser
      .executeScript(() => {
        window.component.render();
        window.component.init();
        return window.uic;
      });
    })
    .then((_uic_) => {
      uic = _uic_;
    });
  });

  it('should not fire any event if the attr is not clicked', function() {
    return flows.clickBranch([uic.tree[0].name])
    .then(() => {
      return browser
      .executeScript(() => {
        return window.uic.events;
      })
      .then((events) => {
        expect(events).to.have.lengthOf(0);
      });
    });
  });

  describe('attribute:expanded', function() {
    it('should expand the first attribute and fire the event', function() {
      return flows
      .clickBranch([uic.tree[0].name, uic.tree[0].children[0].name])
      .then(() => {
        return browser
        .executeScript(() => {
          return window.uic.events;
        })
        .then((events) => {
          expect(events).to.have.lengthOf(1);
          expect(events[0].event).to.be.eql(expandEvent);
        });
      });
    });

    it('should expand the first attribute two times and fire the event twice',
    function() {
      return flows
      .clickBranch([uic.tree[0].name, uic.tree[0].children[0].name])
      .then(() => {
        return flows
        .clickBranch([uic.tree[0].name, uic.tree[0].children[0].name]);
      })
      .then(() => {
        return flows
        .clickBranch([uic.tree[0].name, uic.tree[0].children[0].name]);
      })
      .then(() => {
        return browser
        .executeScript(() => {
          return window.uic.events;
        })
        .then((events) => {
          expect(events).to.have.lengthOf(3);
          expect(events[0].event).to.be.eql(expandEvent);
          expect(events[2].event).to.be.eql(expandEvent);
        });
      });
    });
  });

  describe('attribute:collapsed', function() {
    it('should collapse the first attribute and fire the event', function() {
      return flows
      .clickBranch([uic.tree[0].name, uic.tree[0].children[0].name])
      .then(() => {
        return flows
        .clickBranch([uic.tree[0].name, uic.tree[0].children[0].name]);
      })
      .then(() => {
        return browser
        .executeScript(() => {
          return window.uic.events;
        })
        .then((events) => {
          expect(events).to.have.lengthOf(2);
          expect(events[1].event).to.be.eql(collapseEvent);
        });
      });
    });

    it('should collapse the first attribute two times and fire the event twice',
      function() {
        return flows
        .clickBranch([uic.tree[0].name, uic.tree[0].children[0].name])
        .then(() => {
          return flows
          .clickBranch([uic.tree[0].name, uic.tree[0].children[0].name]);
        })
        .then(() => {
          return flows
          .clickBranch([uic.tree[0].name, uic.tree[0].children[0].name]);
        })
        .then(() => {
          return flows
          .clickBranch([uic.tree[0].name, uic.tree[0].children[0].name]);
        })
        .then(() => {
          return browser
          .executeScript(() => {
            return window.uic.events;
          })
          .then((events) => {
            expect(events).to.have.lengthOf(4);
            expect(events[1].event).to.be.eql(collapseEvent);
            expect(events[3].event).to.be.eql(collapseEvent);
          });
        });
      });
  });
});
