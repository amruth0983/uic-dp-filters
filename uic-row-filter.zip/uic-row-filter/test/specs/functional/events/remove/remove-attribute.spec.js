describe('Event: remove:attribute', function() {
  var removeEvent = 'remove:attribute',
    uic;

  beforeEach(function() {
    return setTestTemplate(__dirname, 'remove-attribute.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    })
    .then(() => {
      return browser
      .executeScript(() => {
        window.component.render();
        window.component.init();

        return window.uic;
      });
    })
    .then((_uic_) => {
      uic = _uic_;
    });
  });

  it('should not fire any event if \'clear attr.\' is not clicked', function() {
    return flows.clickBranch([uic.tree[0].name])
    .then(() => {
      return browser
      .executeScript(() => {
        return window.uic.events;
      })
      .then((events) => {
        expect(events).to.have.lengthOf(0);
      });
    });
  });

  it('should check one attribute and clear it', function() {
    return flows
    .toggleValue(
      [uic.tree[0].name, uic.tree[0].children[0].name],
      uic.tree[0].children[0].values[0].name
    )
    .then(() => {
      return flows
      .clearBranch(uic.tree[0].children[0].name);
    })
    .then(() => {
      return browser
      .executeScript(() => {
        return window.uic.events;
      })
      .then((events) => {
        expect(events).to.have.lengthOf(1);
        expect(events[0].event).to.be.eql(removeEvent);
      });
    });
  });

  it('should check values in two attributes and clear only one', function() {
    return flows
    .toggleValue(
      [uic.tree[0].name, uic.tree[0].children[0].name],
      uic.tree[0].children[0].values[0].name
    )
    .then(() => {
      return flows
      .toggleValue(
        [uic.tree[1].name, uic.tree[1].children[0].name],
        uic.tree[1].children[0].values[0].name
      );
    })
    .then(() => {
      return flows
      .clearBranch(uic.tree[1].children[0].name);
    })
    .then(() => {
      return browser
      .executeScript(() => {
        return window.uic.events;
      })
      .then((events) => {
        expect(events).to.have.lengthOf(1);
        expect(events[0].event).to.be.eql(removeEvent);
        expect(events[0].data.section.name).to.be.eql(uic.tree[1].name);
      });
    })
    .then(() => {
      return flows
      .clickBranch([uic.tree[0].name, uic.tree[0].children[0].name]);
    })
    .then(() => {
      return flows
      .getCheckboxFor(uic.tree[0].children[0].values[0].name)
      .getAttribute('class')
      .then((classes) => {
        expect(classes).to.contain('checked');
      });
    });
  });
});
