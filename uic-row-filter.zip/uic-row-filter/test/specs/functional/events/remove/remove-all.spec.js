describe('Event: remove:all', function() {
  var clearAllEvent = 'remove:all',
    uic;

  beforeEach(function() {
    return setTestTemplate(__dirname, 'remove-all.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    })
    .then(() => {
      return browser
      .executeScript(() => {
        window.component.render();
        window.component.init();

        return window.uic;
      });
    })
    .then((_uic_) => {
      uic = _uic_;
    });
  });

  it('should not fire any event if \'clear all\' is not clicked', function() {
    return flows.clickBranch([uic.tree[0].name])
    .then(() => {
      return browser
      .executeScript(() => {
        return window.uic.events;
      });
    })
    .then((events) => {
      expect(events).to.have.lengthOf(0);
    });
  });

  it('should check one attribute and clear all the attributes', function() {
    return flows
    .toggleValue(
      [uic.tree[0].name, uic.tree[0].children[0].name],
      uic.tree[0].children[0].values[0].name
    )
    .then(() => {
      return flows.clearGlobal();
    })
    .then(() => {
      return browser
      .executeScript(() => {
        return window.uic.events;
      })
      .then((events) => {
        expect(events).to.have.lengthOf(1);
        expect(events[0].event).to.be.eql(clearAllEvent);
      });
    });
  });

  it('should not check any value and fire the event', function() {
    return flows
    .clearGlobal()
    .then(() => {
      return browser
      .executeScript(() => {
        return window.uic.events;
      })
      .then((events) => {
        expect(events).to.have.lengthOf(1);
        expect(events[0].event).to.be.eql(clearAllEvent);
      });
    });
  });
});
