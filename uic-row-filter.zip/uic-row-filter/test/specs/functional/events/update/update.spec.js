describe('Event: update', function() {
  var updateValueEvent = 'update:value',
    updateValueSingleEvent = 'update:value:single',
    uic;

  beforeEach(function() {
    return setTestTemplate(__dirname, 'update.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    })
    .then(() => {
      return browser
      .executeScript(() => {
        window.component.render();
        window.component.init();

        return window.uic;
      });
    })
    .then((_uic_) => {
      uic = _uic_;
    });
  });

  it('should not fire any event if any value is clicked', function() {
    return flows.clickBranch([uic.tree[0].name])
    .then(() => {
      return browser
      .executeScript(() => {
        return window.uic.events;
      })
      .then((events) => {
        expect(events).to.have.lengthOf(0);
      });
    });
  });

  describe('update:value', function() {
    it('should check one value and fire the event', function() {
      return flows
      .toggleValue(
        [uic.tree[0].name, uic.tree[0].children[0].name],
        uic.tree[0].children[0].values[0].name
      )
      .then(() => {
        return browser
        .executeScript(() => {
          return window.uic.events;
        })
        .then((events) => {
          expect(events).to.have.lengthOf(1);
          expect(events[0].event).to.be.eql(updateValueEvent);
        });
      });
    });

    it('should check two values on the same attribute', function() {
      return flows
      .toggleValue(
        [uic.tree[0].name, uic.tree[0].children[0].name],
        uic.tree[0].children[0].values[0].name
      )
      .then(() => {
        return flows
        .clickValueCheckbox(uic.tree[0].children[0].values[1].name);
      })
      .then(() => {
        return browser
        .executeScript(() => {
          return window.uic.events;
        })
        .then((events) => {
          expect(events).to.have.lengthOf(2);
          expect(events[0].event).to.be.eql(updateValueEvent);
          expect(events[1].event).to.be.eql(updateValueEvent);
        });
      });
    });

    it('should check values in two attributes and fire two events', function() {
      return flows
      .toggleValue(
        [uic.tree[0].name, uic.tree[0].children[0].name],
        uic.tree[0].children[0].values[0].name
      )
      .then(() => {
        return flows
        .toggleValue(
          [uic.tree[1].name, uic.tree[1].children[0].name],
          uic.tree[1].children[0].values[0].name
        );
      })
      .then(() => {
        return browser
        .executeScript(() => {
          return window.uic.events;
        })
        .then((events) => {
          expect(events).to.have.lengthOf(2);
          expect(events[0].event).to.be.eql(updateValueEvent);
          expect(events[1].event).to.be.eql(updateValueEvent);
        });
      });
    });
  });

  describe('update:value:single', function() {
    it('should check one value and fire the event', function() {
      return flows
      .toggleSingleValue(
        [uic.tree[0].name, uic.tree[0].children[0].name],
        uic.tree[0].children[0].values[0].name
      )
      .then(() => {
        return browser
        .executeScript(() => {
          return window.uic.events;
        })
        .then((events) => {
          expect(events).to.have.lengthOf(1);
          expect(events[0].event).to.be.eql(updateValueSingleEvent);
        });
      });
    });

    it('should check and uncheck the same value', function() {
      return flows
      .toggleSingleValue(
        [uic.tree[0].name, uic.tree[0].children[0].name],
        uic.tree[0].children[0].values[0].name
      )
      .then(() => {
        return flows
        .clickValueLabel(uic.tree[0].children[0].values[0].name);
      })
      .then(() => {
        return browser
        .executeScript(() => {
          return window.uic.events;
        })
        .then((events) => {
          expect(events).to.have.lengthOf(2);
          expect(events[0].event).to.be.eql(updateValueSingleEvent);
          expect(events[1].event).to.be.eql(updateValueSingleEvent);
        });
      });
    });

    it('should check two values on the same attribute', function() {
      return flows
      .toggleSingleValue(
        [uic.tree[0].name, uic.tree[0].children[0].name],
        uic.tree[0].children[0].values[0].name
      )
      .then(() => {
        return flows
        .clickValueLabel(uic.tree[0].children[0].values[1].name);
      })
      .then(() => {
        return browser
        .executeScript(() => {
          return window.uic.events;
        })
        .then((events) => {
          expect(events).to.have.lengthOf(2);
          expect(events[0].event).to.be.eql(updateValueSingleEvent);
          expect(events[1].event).to.be.eql(updateValueSingleEvent);
        });
      });
    });

    it('should check values in two attributes and fire two events', function() {
      return flows
      .toggleSingleValue(
        [uic.tree[0].name, uic.tree[0].children[0].name],
        uic.tree[0].children[0].values[0].name
      )
      .then(() => {
        return flows
        .toggleSingleValue(
          [uic.tree[1].name, uic.tree[1].children[0].name],
          uic.tree[1].children[0].values[0].name
        );
      })
      .then(() => {
        return browser
        .executeScript(() => {
          return window.uic.events;
        })
        .then((events) => {
          expect(events).to.have.lengthOf(2);
          expect(events[0].event).to.be.eql(updateValueSingleEvent);
          expect(events[1].event).to.be.eql(updateValueSingleEvent);
        });
      });
    });
  });
});
