describe('Event: unblock', function() {
  var unblockSectionEvent = 'unblock:section',
    unblockAllEvent = 'unblock:all',
    uic;

  beforeEach(function() {
    return setTestTemplate(__dirname, 'unblock.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    })
    .then(() => {
      return browser
      .executeScript(() => {
        window.component.render();
        window.component.init();

        return window.uic;
      });
    })
    .then((_uic_) => {
      uic = _uic_;
    });
  });

  it('should not fire any event if unblock is not clicked', function() {
    return browser
    .executeScript(() => {
      return window.uic.events;
    })
    .then((events) => {
      expect(events).to.have.lengthOf(0);
    });
  });

  describe('unblock:section', function() {
    it('should fire unblock when unblocking a section', function() {
      return flows
      .clearBranch(uic.tree[0].name)
      .then(() => {
        return browser
        .executeScript(() => {
          return window.uic.events;
        })
        .then((events) => {
          expect(events).to.have.lengthOf(1);
          expect(events[0].event).to.be.eql(unblockSectionEvent);
        });
      });
    });

    it('should fire unblock when unblocking a inner section', function() {
      return flows
      .clickBranch(uic.tree[2].name)
      .then(() => {
        return flows.clearBranch(uic.tree[2].children[0].name);
      })
      .then(() => {
        return browser
        .executeScript(() => {
          return window.uic.events;
        })
        .then((events) => {
          expect(events).to.have.lengthOf(1);
          expect(events[0].event).to.be.eql(unblockSectionEvent);
        });
      });
    });

    it('should fire unblock when unblocking two sections', function() {
      return flows.clearBranch(uic.tree[0].name)
      .then(() => {
        return flows.clearBranch(uic.tree[1].name);
      })
      .then(() => {
        return browser
        .executeScript(() => {
          return window.uic.events;
        })
        .then((events) => {
          expect(events).to.have.lengthOf(2);
          expect(events[0].event).to.be.eql(unblockSectionEvent);
          expect(events[1].event).to.be.eql(unblockSectionEvent);
        });
      });
    });
  });

  describe('unblock:all', function() {
    it('should fire unblock when unblocking all the sections', function() {
      return flows.clearGlobal()
      .then(() => {
        return browser
        .executeScript(() => {
          return window.uic.events;
        })
        .then((events) => {
          expect(events).to.have.lengthOf(1);
          expect(events[0].event).to.be.eql(unblockAllEvent);
        });
      });
    });
  });
});
