describe('Component: .updateConfig(tree)', function() {
  var componentId = 'component',
    uic;

  beforeEach(function() {
    return setTestTemplate(__dirname, 'tree.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    })
    .then(() => {
      return browser
      .executeScript(() => {
        return window.uic;
      });
    })
    .then((_uic_) => {
      uic = _uic_;
    });
  });

  describe('before rendering', function() {
    it('should update the tree of the uic', function() {
      return browser
      .executeScript(() => {
        var component = window.component.updateConfig({
          rowFilterTree: window.uic.tree
        });

        return component.config.rowFilterTree;
      })
      .then((rowFilterTree) => {
        expect(rowFilterTree).to.be.eql(uic.tree);
      })
      .then(() => {
        return browser
        .element(by.id(componentId))
        .getText()
        .then((text) => {
          expect(text).to.be.empty;
        });
      });
    });
  });

  describe('after rendering', function() {
    beforeEach(function() {
      return browser
      .executeScript(() => {
        window.component.render();
      });
    });

    it('should update the tree of the uic', function() {
      return browser
      .executeScript(() => {
        var component = window.component.updateConfig({
          rowFilterTree: window.uic.tree
        });

        return component.config.rowFilterTree;
      })
      .then((rowFilterTree) => {
        expect(rowFilterTree.name).to.be.eql(uic.tree.name);
      })
      .then(() => {
        return flows
        .clickBranch([uic.tree[0].name, uic.tree[0].children[0].name]);
      })
      .then(() => {
        return flows
        .getBranchFor(uic.tree[0].name)
        .getText()
        .then((text) => {
          expect(text).to.be.eql(uic.tree[0].label);
        });
      })
      .then(() => {
        return flows
        .getBranchFor(uic.tree[0].children[0].label)
        .getText()
        .then((text) => {
          expect(text).to.be.eql(uic.tree[0].children[0].label);
        });
      })
      .then(() => {
        return flows
        .getValueFor(uic.tree[0].children[0].values[0].label)
        .getText()
        .then((text) => {
          expect(text).to.contain(uic.tree[0].children[0].values[0].label);
        });
      });
    });
  });
});
