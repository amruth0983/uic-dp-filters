describe('Component: .updateConfig(className)', function() {
  var defaultClassName = 'uic-row-filter';

  beforeEach(function() {
    return setTestTemplate(__dirname, 'class-name.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    });
  });

  describe('before rendering', function() {
    it('should have the default UIC class-name if there is no custom class',
      function() {
        return browser
        .executeScript(() => {
          window.component
          .render()
          .init();
        })
        .then(() => {
          return $('div[data-uic-row-filter]')
          .getAttribute('class')
          .then((classNames) => {
            expect(utils.splitStr(classNames)).to.have.lengthOf(1)
              .and.to.include(defaultClassName);
          });
        });
      }
    );

    it('should add the given class-name to the component', function() {
      return browser
      .executeScript(() => {
        var customClassName = 'custom-class-name';

        window.component
        .updateConfig({
          className: customClassName
        })
        .render()
        .init();

        return customClassName;
      })
      .then((customClassName) => {
        return $('div[data-uic-row-filter]')
        .getAttribute('class')
        .then((classNames) => {
          expect(utils.splitStr(classNames)).to.have.lengthOf(2);

          [defaultClassName, customClassName].forEach((className) => {
            expect(utils.splitStr(classNames)).to.include(className);
          });
        });
      });
    });
  });

  describe('after rendering', function() {
    it('should add the given class-name to the component', function() {
      return browser
      .executeScript(() => {
        window.component
        .render()
        .init();
      })
      .then(() => {
        return $('div[data-uic-row-filter]')
        .getAttribute('class')
        .then((classNames) => {
          expect(utils.splitStr(classNames)).to.have.lengthOf(1);
        });
      })
      .then(() => {
        return browser
        .executeScript(() => {
          var customClassName = 'custom-class-name';

          window.component
          .updateConfig({
            className: customClassName
          })
          .render()
          .init();

          return customClassName;
        });
      })
      .then((customClassName) => {
        return $('div[data-uic-row-filter]')
        .getAttribute('class')
        .then((classNames) => {
          expect(utils.splitStr(classNames)).to.have.lengthOf(2)
            .and.to.include(customClassName);
        });
      });
    });
  });
});
