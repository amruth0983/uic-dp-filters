describe('Component: .render()', function() {
  beforeEach(function() {
    return setTestTemplate(__dirname, 'render.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    })
    .then(() => {
      return browser
      .executeScript(() => {
        window.component.render();
        window.component.init();
      });
    });
  });

  it('should render the component', function() {
    return $('div[data-uic-row-filter]')
    .isDisplayed()
    .then((disp) => {
      expect(disp).to.be.true;
    })
    .then(() => {
      return $('div[data-uic-row-filter]');
    })
    .then((element) => {
      return element
      .getAttribute('class')
      .then((result) => {
        expect(result).to.contain('uic-row-filter');
      });
    });
  });
});
