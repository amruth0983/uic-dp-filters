describe('Component: toggle-collapse methods', function() {
  var expandedClass = 'expanded',
    uic;

  beforeEach(function() {
    return setTestTemplate(__dirname, 'toggle-collapse.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    })
    .then(() => {
      return browser
      .executeScript(() => {
        window.component.render();
        window.component.init();
        return window.uic;
      });
    })
    .then((_uic_) => {
      uic = _uic_;
    });
  });

  describe('.toggleSectionCollapse()', function() {
    it('should collapse the first section', function() {
      return browser
      .executeScript(() => {
        window.component.toggleSectionCollapse(
          window.uic.tree,
          window.uic.tree[0]
        );
      })
      .then(() => {
        return flows
        .getBranchFor(uic.tree[0].name)
        .getAttribute('class');
      })
      .then((classes) => {
        expect(classes).to.contain(expandedClass);
        return browser
        .executeScript(() => {
          window.component.toggleSectionCollapse(
            window.uic.tree,
            window.uic.tree[0]
          );
        });
      })
      .then(() => {
        return flows
        .getBranchFor(uic.tree[0].name)
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.not.contain(expandedClass);
        });
      });
    });

    it('should collapse the first and then the second section', function() {
      return browser
      .executeScript(() => {
        window.component.toggleSectionCollapse(
          window.uic.tree,
          window.uic.tree[0]
        );
      })
      .then(() => {
        return flows
        .getBranchFor(uic.tree[0].name)
        .getAttribute('class');
      })
      .then((classes) => {
        expect(classes).to.contain(expandedClass);
        return browser
        .executeScript(() => {
          window.component.toggleSectionCollapse(
            window.uic.tree,
            window.uic.tree[1]
          );
        });
      })
      .then(() => {
        return flows
        .getBranchFor(uic.tree[0].name)
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.not.contain(expandedClass);
        });
      })
      .then(() => {
        return flows
        .getBranchFor(uic.tree[1].name)
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.contain(expandedClass);
        });
      });
    });
  });

  describe('.toggleAttributeCollapse()', function() {
    it('should collapse the first attribute', function() {
      return flows.clickBranch(uic.tree[0].name)
      .then(() => {
        return browser
        .executeScript(() => {
          window.component.toggleAttributeCollapse(
            window.uic.tree[0],
            window.uic.tree[0].children,
            window.uic.tree[0].children[0]
          );
        });
      })
      .then(() => {
        return flows
        .getBranchFor(uic.tree[0].name)
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.contain(expandedClass);
        });
      });
    });

    it('should collapse the first attribute without opening the section' +
      ' and do not collapse it', function() {
      return browser
      .executeScript(() => {
        window.component.toggleAttributeCollapse(
          window.uic.tree[0],
          window.uic.tree[0].children,
          window.uic.tree[0].children[0]
        );
      })
      .then(() => {
        return flows
        .getBranchFor(uic.tree[0].name)
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.not.contain(expandedClass);
        });
      });
    });
  });
});
