describe('Component: toggle-attribute methods', function() {
  var checkedClass = 'checked',
    uic;

  beforeEach(function() {
    return setTestTemplate(__dirname, 'toggle-attribute.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    })
    .then(() => {
      return browser
      .executeScript(() => {
        window.component.render();
        window.component.init();
        return window.uic;
      });
    })
    .then((_uic_) => {
      uic = _uic_;
    });
  });

  describe('.toggleAttributeValue()', function() {
    it('should toggle the first attribute', function() {
      return flows.clickBranch([uic.tree[0].name, uic.tree[0].children[0].name])
      .then(() => {
        return browser
        .executeScript(() => {
          window.component.toggleAttributeValue(
            window.uic.tree[0],
            window.uic.tree[0].children[0].values,
            window.uic.tree[0].children[0],
            window.uic.tree[0].children[0].values[0]
          );
        });
      })
      .then(() => {
        return flows
        .getCheckboxFor(uic.tree[0].children[0].values[0].name);
      })
      .then((checkbox) => {
        return checkbox
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.contain(checkedClass);
        });
      });
    });

    it('should toggle two times the first attribute', function() {
      return flows.clickBranch([uic.tree[0].name, uic.tree[0].children[0].name])
      .then(() => {
        return browser
        .executeScript(() => {
          window.component.toggleAttributeValue(
            window.uic.tree[0],
            window.uic.tree[0].children[0].values,
            window.uic.tree[0].children[0],
            window.uic.tree[0].children[0].values[0]
          );
        });
      })
      .then(() => {
        return flows
        .getCheckboxFor(uic.tree[0].children[0].values[0].name);
      })
      .then((checkbox) => {
        return checkbox
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.contain(checkedClass);
        });
      })
      .then(() => {
        return browser
        .executeScript(() => {
          window.component.toggleAttributeValue(
            window.uic.tree[0],
            window.uic.tree[0].children[0].values,
            window.uic.tree[0].children[0],
            window.uic.tree[0].children[0].values[0]
          );
        });
      })
      .then(() => {
        return flows
        .getCheckboxFor(uic.tree[0].children[0].values[0].name);
      })
      .then((checkbox) => {
        return checkbox
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.not.contain(checkedClass);
        });
      });
    });

    it('should toggle the first attribute and the second should not be checked',
      function() {
        return flows.clickBranch([
          uic.tree[0].name, uic.tree[0].children[0].name
        ])
        .then(() => {
          return browser
          .executeScript(() => {
            window.component.toggleAttributeValue(
              window.uic.tree[0],
              window.uic.tree[0].children[0].values,
              window.uic.tree[0].children[0],
              window.uic.tree[0].children[0].values[0]
            );
          });
        })
        .then(() => {
          return flows
          .getCheckboxFor(uic.tree[0].children[0].values[0].name);
        })
        .then((checkbox) => {
          return checkbox
          .getAttribute('class')
          .then((classes) => {
            expect(classes).to.contain(checkedClass);
          });
        })
        .then(() => {
          return flows
          .getCheckboxFor(uic.tree[0].children[0].values[1].name);
        })
        .then((checkbox) => {
          return checkbox
          .getAttribute('class')
          .then((classes) => {
            expect(classes).to.not.contain(checkedClass);
          });
        });
      }
    );

    it('should toggle the first and the third attribute', function() {
      return flows.clickBranch([uic.tree[0].name, uic.tree[0].children[0].name])
      .then(() => {
        return browser
        .executeScript(() => {
          window.component.toggleAttributeValue(
            window.uic.tree[0],
            window.uic.tree[0].children[0].values,
            window.uic.tree[0].children[0],
            window.uic.tree[0].children[0].values[0]
          );

          window.component.toggleAttributeValue(
            window.uic.tree[0],
            window.uic.tree[0].children[0].values,
            window.uic.tree[0].children[0],
            window.uic.tree[0].children[0].values[2]
          );
        });
      })
      .then(() => {
        return flows
        .getCheckboxFor(uic.tree[0].children[0].values[0].name);
      })
      .then((checkbox) => {
        return checkbox
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.contain(checkedClass);
        });
      })
      .then(() => {
        return flows
        .getCheckboxFor(uic.tree[0].children[0].values[2].name);
      })
      .then((checkbox) => {
        return checkbox
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.contain(checkedClass);
        });
      });
    });
  });

  describe('.toggleSingleAttribute()', function() {
    it('should toggle the first attribute', function() {
      return flows.clickBranch([uic.tree[0].name, uic.tree[0].children[0].name])
      .then(() => {
        return browser
        .executeScript(() => {
          window.component.toggleSingleAttribute(
            window.uic.tree[0],
            window.uic.tree[0].children[0].values,
            window.uic.tree[0].children[0],
            window.uic.tree[0].children[0].values[0]
          );
        });
      })
      .then(() => {
        return flows
        .getCheckboxFor(uic.tree[0].children[0].values[0].name);
      })
      .then((checkbox) => {
        return checkbox
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.contain(checkedClass);
        });
      });
    });

    it('should toggle two times the first attribute', function() {
      return flows.clickBranch([uic.tree[0].name, uic.tree[0].children[0].name])
      .then(() => {
        return browser
        .executeScript(() => {
          window.component.toggleSingleAttribute(
            window.uic.tree[0],
            window.uic.tree[0].children[0].values,
            window.uic.tree[0].children[0],
            window.uic.tree[0].children[0].values[0]
          );
        });
      })
      .then(() => {
        return flows
        .getCheckboxFor(uic.tree[0].children[0].values[0].name);
      })
      .then((checkbox) => {
        return checkbox
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.contain(checkedClass);
        });
      })
      .then(() => {
        return browser
        .executeScript(() => {
          window.component.toggleSingleAttribute(
            window.uic.tree[0],
            window.uic.tree[0].children[0].values,
            window.uic.tree[0].children[0],
            window.uic.tree[0].children[0].values[0]
          );
        });
      })
      .then(() => {
        return flows
        .getCheckboxFor(uic.tree[0].children[0].values[0].name);
      })
      .then((checkbox) => {
        return checkbox
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.not.contain(checkedClass);
        });
      });
    });

    it('should toggle the first and then the third attribute', function() {
      return flows.clickBranch([uic.tree[0].name, uic.tree[0].children[0].name])
      .then(() => {
        return browser
        .executeScript(() => {
          window.component.toggleSingleAttribute(
            window.uic.tree[0],
            window.uic.tree[0].children[0].values,
            window.uic.tree[0].children[0],
            window.uic.tree[0].children[0].values[0]
          );
        });
      })
      .then(() => {
        return flows
        .getCheckboxFor(uic.tree[0].children[0].values[0].name);
      })
      .then((checkbox) => {
        return checkbox
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.contain(checkedClass);
        });
      })
      .then(() => {
        return browser
        .executeScript(() => {
          window.component.toggleSingleAttribute(
            window.uic.tree[0],
            window.uic.tree[0].children[0].values,
            window.uic.tree[0].children[0],
            window.uic.tree[0].children[0].values[2]
          );
        });
      })
      .then(() => {
        return flows
        .getCheckboxFor(uic.tree[0].children[0].values[0].name);
      })
      .then((checkbox) => {
        return checkbox
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.not.contain(checkedClass);
        });
      })
      .then(() => {
        return flows
        .getCheckboxFor(uic.tree[0].children[0].values[2].name);
      })
      .then((checkbox) => {
        return checkbox
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.contain(checkedClass);
        });
      });
    });

    it('should toggle the three attributes with the method ' +
      '.toggleAttributeValue() and then the first attribute', function() {
      return flows.clickBranch([uic.tree[0].name, uic.tree[0].children[0].name])
      .then(() => {
        return browser
        .executeScript(() => {
          window.component.toggleAttributeValue(
            window.uic.tree[0],
            window.uic.tree[0].children[0].values,
            window.uic.tree[0].children[0],
            window.uic.tree[0].children[0].values[0]
          );

          window.component.toggleAttributeValue(
            window.uic.tree[0],
            window.uic.tree[0].children[0].values,
            window.uic.tree[0].children[0],
            window.uic.tree[0].children[0].values[1]
          );

          window.component.toggleAttributeValue(
            window.uic.tree[0],
            window.uic.tree[0].children[0].values,
            window.uic.tree[0].children[0],
            window.uic.tree[0].children[0].values[2]
          );
        });
      })
      .then(() => {
        return flows
        .getCheckboxFor(uic.tree[0].children[0].values[0].name);
      })
      .then((checkbox) => {
        return checkbox
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.contain(checkedClass);
        });
      })
      .then(() => {
        return flows
        .getCheckboxFor(uic.tree[0].children[0].values[1].name);
      })
      .then((checkbox) => {
        return checkbox
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.contain(checkedClass);
        });
      })
      .then(() => {
        return flows
        .getCheckboxFor(uic.tree[0].children[0].values[2].name);
      })
      .then((checkbox) => {
        return checkbox
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.contain(checkedClass);
        });
      })
      .then(() => {
        return browser
        .executeScript(() => {
          window.component.toggleSingleAttribute(
            window.uic.tree[0],
            window.uic.tree[0].children[0].values,
            window.uic.tree[0].children[0],
            window.uic.tree[0].children[0].values[0]
          );
        });
      })
      .then(() => {
        return flows
        .getCheckboxFor(uic.tree[0].children[0].values[0].name);
      })
      .then((checkbox) => {
        return checkbox
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.contain(checkedClass);
        });
      })
      .then(() => {
        return flows
        .getCheckboxFor(uic.tree[0].children[0].values[1].name);
      })
      .then((checkbox) => {
        return checkbox
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.not.contain(checkedClass);
        });
      })
      .then(() => {
        return flows
        .getCheckboxFor(uic.tree[0].children[0].values[2].name);
      })
      .then((checkbox) => {
        return checkbox
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.not.contain(checkedClass);
        });
      });
    });
  });
});
