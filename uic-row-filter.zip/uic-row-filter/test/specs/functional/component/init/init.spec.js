describe('Component: .init()', function() {
  beforeEach(function() {
    return setTestTemplate(__dirname, 'init.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    });
  });

  describe('(before render)', function() {
    it('should not initialize the uic if it is not rendered', function() {
      return browser
      .executeScript(() => {
        return window.component
        .init()
        .isInitialized;
      })
      .then((isInitialized) => {
        expect(isInitialized).to.be.false;
      });
    });
  });

  describe('(after render)', function() {
    beforeEach(function() {
      return browser
      .executeScript(() => {
        window.component.render();
      });
    });

    it('should initialize the uic after rendering', function() {
      return browser
      .executeScript(() => {
        return window.component
        .init()
        .isInitialized;
      })
      .then((isInitialized) => {
        expect(isInitialized).to.be.true;
      });
    });

    it('should initialize two times the uic after rendering', function() {
      return browser
      .executeScript(() => {
        return window.component
        .init()
        .isInitialized;
      })
      .then((isInitialized) => {
        expect(isInitialized).to.be.true;

        return browser
        .executeScript(() => {
          return window.component
          .init()
          .isInitialized;
        })
        .then((isInitialized) => {
          expect(isInitialized).to.be.true;
        });
      });
    });
  });
});
