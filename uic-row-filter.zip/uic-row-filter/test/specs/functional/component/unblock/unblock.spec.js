describe('Component: unblock methods', function() {
  var checkedClass = 'checked',
    blockedClass = 'blocked',
    uic;

  beforeEach(function() {
    return setTestTemplate(__dirname, 'unblock.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    })
    .then(() => {
      return browser
      .executeScript(() => {
        window.component.render();
        window.component.init();

        return window.uic;
      });
    })
    .then((_uic_) => {
      uic = _uic_;
    });
  });

  describe('.unblockAll()', function() {
    it('should unblock all the attributes', function() {
      return flows
      .getBranchFor(uic.tree[0].name)
      .getAttribute('class')
      .then((classes) => {
        expect(classes).to.contain(blockedClass);
      })
      .then(() => {
        return browser
        .executeScript(() => {
          window.component.unblockAll();
        });
      })
      .then(() => {
        return flows
        .getBranchFor(uic.tree[0].name)
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.not.contain(blockedClass);
        });
      });
    });

    it('should unblock all and still having checked attributes', function() {
      return flows
      .getBranchFor(uic.tree[0].name)
      .getAttribute('class')
      .then((classes) => {
        expect(classes).to.contain(blockedClass);
      })
      .then(() => {
        return browser
        .executeScript(() => {
          window.component.unblockAll();
        });
      })
      .then(() => {
        return flows
        .getBranchFor(uic.tree[0].name)
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.not.contain(blockedClass);
        });
      })
      .then(() => {
        return flows
        .clickBranch([uic.tree[0].name, uic.tree[0].children[0].name]);
      })
      .then(() => {
        return flows
        .getCheckboxFor(uic.tree[0].children[0].values[0].label)
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.contain(checkedClass);
        });
      });
    });
  });

  describe('.unblockSection()', function() {
    it('should unblock a section', function() {
      return flows
      .getBranchFor(uic.tree[0].name)
      .getAttribute('class')
      .then((classes) => {
        expect(classes).to.contain(blockedClass);
      })
      .then(() => {
        return browser
        .executeScript(() => {
          window.component.unblockSection(
            window.uic.tree[0]
          );
        });
      })
      .then(() => {
        return flows
        .getBranchFor(uic.tree[0].name)
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.not.contain(blockedClass);
        });
      });
    });

    it('should unblock a section and still having checked attributes',
    function() {
      return flows
      .getBranchFor(uic.tree[0].name)
      .getAttribute('class')
      .then((classes) => {
        expect(classes).to.contain(blockedClass);
      })
      .then(() => {
        return browser
        .executeScript(() => {
          window.component.unblockSection(
            window.uic.tree[0]
          );
        });
      })
      .then(() => {
        return flows
        .getBranchFor(uic.tree[0].name)
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.not.contain(blockedClass);
        });
      })
      .then(() => {
        return flows
        .clickBranch([uic.tree[0].name, uic.tree[0].children[0].name]);
      })
      .then(() => {
        return flows
        .getCheckboxFor(uic.tree[0].children[0].values[0].label)
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.contain(checkedClass);
        });
      });
    });
  });
});
