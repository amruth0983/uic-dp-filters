describe('Component: collapse methods', function() {
  var expandedClass = 'expanded',
    uic;

  beforeEach(function() {
    return setTestTemplate(__dirname, 'collapse.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    })
    .then(() => {
      return browser
      .executeScript(() => {
        window.component.render();
        window.component.init();
        return window.uic;
      });
    })
    .then((_uic_) => {
      uic = _uic_;
    });
  });

  describe('.collapseAll()', function() {
    it('should collapse all the sections', function() {
      return flows
      .clickBranch([uic.tree[0].name, uic.tree[0].children[0].name])
      .then(() => {
        return flows
        .getBranchFor(uic.tree[0].name)
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.contain(expandedClass);
        });
      })
      .then(() => {
        return browser
        .executeScript(() => {
          window.component.collapseAll(window.uic.tree);
        });
      })
      .then(() => {
        return flows
        .getBranchFor(uic.tree[0].name)
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.not.contain(expandedClass);
        });
      });
    });
  });

  describe('.collapseAllAttributes()', function() {
    it('should collapse all the attributes', function() {
      return flows
      .clickBranch([uic.tree[0].name, uic.tree[0].children[0].name])
      .then(() => {
        return flows
        .getBranchFor(uic.tree[0].name)
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.contain(expandedClass);
        });
      })
      .then(() => {
        return browser
        .executeScript(() => {
          window.component.collapseAllAttributes(window.uic.tree);
        });
      })
      .then(() => {
        return flows
        .getBranchFor(uic.tree[0].name)
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.contain(expandedClass);
        });
      })
      .then(() => {
        return flows
        .getBranchFor(uic.tree[0].children[0].name)
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.not.contain(expandedClass);
        });
      });
    });
  });
});
