describe('Component: .destroy()', function() {
  beforeEach(function() {
    return setTestTemplate(__dirname, 'destroy.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    })
    .then(() => {
      return browser.executeScript(() => {
        window.component.render();
        window.component.init();
      });
    });
  });

  it('should render and destroy the component', function() {
    return $('div[data-uic-row-filter]')
    .isDisplayed()
    .then((displayed) => {
      expect(displayed).to.be.true;
    })
    .then(() => {
      return browser.executeScript(() => {
        window.component.destroy();
      })
      .then(() => {
        return browser
        .element(by.id('component'))
        .getInnerHtml()
        .then((text) => {
          expect(text).to.have.lengthOf(0);
        });
      });
    });
  });

  it('should render, destroy and render again with the same configuration',
    function() {
      return $('div[data-uic-row-filter]')
      .isDisplayed()
      .then((displayed) => {
        expect(displayed).to.be.true;
      })
      .then(() => {
        return browser
        .executeScript(() => {
          window.component.destroy();
        });
      })
      .then(() => {
        return browser.element(by.id('component'));
      })
      .then((component) => {
        return component
        .getInnerHtml()
        .then((text) => {
          expect(text).to.have.lengthOf(0);
        });
      })
      .then(() => {
        return browser
        .executeScript(() => {
          window.component.render();
        });
      })
      .then(() => {
        return $('div[data-uic-row-filter]')
        .isDisplayed()
        .then((displayed) => {
          expect(displayed).to.be.true;
        });
      });
    });
});
