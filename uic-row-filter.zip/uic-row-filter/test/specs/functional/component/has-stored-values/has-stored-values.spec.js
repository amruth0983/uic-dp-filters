describe('Component: .hasStoredValue()', function() {
  var uic;

  beforeEach(function() {
    return setTestTemplate(__dirname, 'has-stored-values.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    })
    .then(() => {
      return browser
      .executeScript(() => {
        window.component.render();
        window.component.init();

        return window.uic;
      });
    })
    .then((_uic_) => {
      uic = _uic_;
    });
  });

  it('should have a stored value and check it', function() {
    return browser
    .executeScript(() => {
      return window.component.hasStoredValue(window.uic.tree[0]);
    })
    .then((storedValue) => {
      expect(storedValue).to.be.true;
    });
  });

  it('should not have a stored value and check it', function() {
    return browser
    .executeScript(() => {
      return window.component.hasStoredValue(window.uic.tree[1]);
    })
    .then((storedValue) => {
      expect(storedValue).to.be.false;
    });
  });

  it('should not have a stored value and click one, then have it', function() {
    return browser
    .executeScript(() => {
      return window.component.hasStoredValue(window.uic.tree[1]);
    })
    .then((storedValue) => {
      expect(storedValue).to.be.false;
    })
    .then(() => {
      return flows
      .clickBranch([uic.tree[1].name, uic.tree[1].children[0].name]);
    })
    .then(() => {
      return flows
      .clickValueCheckbox(uic.tree[1].children[0].values[0].name);
    })
    .then(() => {
      return browser
      .executeScript(() => {
        return window.component.hasStoredValue(window.uic.tree[1]);
      })
      .then((storedValue) => {
        expect(storedValue).to.be.true;
      });
    });
  });

  it('should have a stored value and uncheck it', function() {
    return browser
    .executeScript(() => {
      return window.component.hasStoredValue(window.uic.tree[0]);
    })
    .then((storedValue) => {
      expect(storedValue).to.be.true;
    })
    .then(() => {
      return flows
      .clickBranch([uic.tree[0].name, uic.tree[0].children[0].name]);
    })
    .then(() => {
      return flows
      .clickValueCheckbox(uic.tree[0].children[0].values[0].name);
    })
    .then(() => {
      return browser
      .executeScript(() => {
        return window.component.hasStoredValue(window.uic.tree[0]);
      })
      .then((storedValue) => {
        expect(storedValue).to.be.false;
      });
    });
  });
});
