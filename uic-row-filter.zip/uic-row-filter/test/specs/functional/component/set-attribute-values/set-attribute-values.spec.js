describe('Component: .setAttrValues() method', function() {
  var uic;

  beforeEach(function() {
    return setTestTemplate(__dirname, 'set-attribute-values.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    })
    .then(() => {
      return browser
      .executeScript(() => {
        window.component
        .render()
        .init()
        .on('attribute:expanded', (data) => {
          window.component.setAttrValues(data.attr, data.attr.values);
        });

        return window.uic;
      });
    })
    .then((_uic_) => {
      uic = _uic_;
    });
  });

  it('should set attribute values', function() {
    return browser
    .executeScript(() => {
      window.component
      .updateConfig({
        rowFilterTree: window.uic.tree
      });
    })
    .then(() => {
      return flows
      .clickBranch([uic.tree[0].name, uic.tree[0].children[0].name]);
    })
    .then(() => {
      return flows
      .getValueFor(uic.tree[0].children[0].values[0].label)
      .isPresent()
      .then((isPresent) => {
        expect(isPresent).to.be.true;
      });
    })
    .then(() => {
      return flows
      .getValueFor(uic.tree[0].children[0].values[1].label)
      .isPresent()
      .then((isPresent) => {
        expect(isPresent).to.be.true;
      });
    })
    .then(() => {
      return flows
      .getValueFor(uic.tree[0].children[0].values[2].label)
      .isPresent()
      .then((isPresent) => {
        expect(isPresent).to.be.true;
      });
    });
  });

  it('should set attribute values for the first and for the second section',
    function() {
      return browser
      .executeScript(() => {
        window.component
        .updateConfig({
          rowFilterTree: window.uic.tree
        });
      })
      .then(() => {
        return flows
        .clickBranch([uic.tree[0].name, uic.tree[0].children[0].name]);
      })
      .then(() => {
        return flows
        .getValueFor(uic.tree[0].children[0].values[0].label)
        .isPresent()
        .then((isPresent) => {
          expect(isPresent).to.be.true;
        });
      })
      .then(() => {
        return flows
        .getValueFor(uic.tree[0].children[0].values[1].label)
        .isPresent()
        .then((isPresent) => {
          expect(isPresent).to.be.true;
        });
      })
      .then(() => {
        return flows
        .getValueFor(uic.tree[0].children[0].values[2].label)
        .isPresent()
        .then((isPresent) => {
          expect(isPresent).to.be.true;
        });
      })
      .then(() => {
        return flows
        .clickBranch([uic.tree[1].name, uic.tree[1].children[0].name]);
      })
      .then(() => {
        return flows
        .getValueFor(uic.tree[1].children[0].values[0].label)
        .isPresent()
        .then((isPresent) => {
          expect(isPresent).to.be.true;
        });
      })
      .then(() => {
        return flows
        .getValueFor(uic.tree[0].children[0].values[0].label)
        .isPresent()
        .then((isPresent) => {
          expect(isPresent).to.be.false;
        });
      })
      .then(() => {
        return flows
        .getValueFor(uic.tree[0].children[0].values[1].label)
        .isPresent()
        .then((isPresent) => {
          expect(isPresent).to.be.false;
        });
      })
      .then(() => {
        return flows
        .getValueFor(uic.tree[0].children[0].values[2].label)
        .isPresent()
        .then((isPresent) => {
          expect(isPresent).to.be.false;
        });
      });
    }
  );

  it('should not set any attribute values', function() {
    return browser
    .executeScript(() => {
      window.component
      .updateConfig({
        rowFilterTree: window.uic.noValuesTree
      });
    })
    .then(() => {
      return flows
      .clickBranch([uic.tree[0].name, uic.tree[0].children[0].name]);
    })
    .then(() => {
      return flows
      .getValueFor(uic.tree[0].children[0].values[0].label)
      .isPresent()
      .then((isPresent) => {
        expect(isPresent).to.be.false;
      });
    });
  });
});
