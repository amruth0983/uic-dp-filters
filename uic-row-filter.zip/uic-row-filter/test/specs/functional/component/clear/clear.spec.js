describe('Component: clear methods', function() {
  var closeIconClass = 'icomoon-close',
    checkedClass = 'checked',
    uic;

  beforeEach(function() {
    return setTestTemplate(__dirname, 'clear.html')
    .then(() => {
      return browser.driver.get(browser.baseUrl);
    })
    .then(() => {
      return browser
      .executeScript(() => {
        window.component.render();
        window.component.init();
        return window.uic;
      });
    })
    .then((_uic_) => {
      uic = _uic_;
    });
  });

  describe('.clearAll()', function() {
    it('should clear all the attributes', function() {
      return flows
      .clickBranch([uic.tree[0].name, uic.tree[0].children[0].name])
      .then(() => {
        return flows
        .clickValueCheckbox(uic.tree[0].children[0].values[0].name);
      })
      .then(() => {
        return browser
        .element(by.className(closeIconClass))
        .isDisplayed()
        .then((displayed) => {
          expect(displayed).to.be.true;
        });
      })
      .then(() => {
        return browser
        .executeScript(() => {
          window.component.clearAll();
        });
      })
      .then(() => {
        return flows
        .getCheckboxFor(uic.tree[0].children[0].values[0].name)
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.not.contain(checkedClass);
        });
      });
    });
  });

  describe('.clearSection()', function() {
    it('should clear a section', function() {
      return flows
      .clickBranch([uic.tree[0].name, uic.tree[0].children[0].name])
      .then(() => {
        return flows
        .clickValueCheckbox(uic.tree[0].children[0].values[0].name);
      })
      .then(() => {
        return browser
        .executeScript(() => {
          window.component.clearSection(
            window.uic.tree[0].children[0]
          );
        });
      })
      .then(() => {
        return flows
        .getCheckboxFor(uic.tree[0].children[0].values[0].name)
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.not.contain(checkedClass);
        });
      });
    });
  });

  describe('.clearAttribute()', function() {
    it('should clear an attribute', function() {
      return flows
      .clickBranch([uic.tree[0].name, uic.tree[0].children[0].name])
      .then(() => {
        return flows
        .clickValueCheckbox(uic.tree[0].children[0].values[0].name);
      })
      .then(() => {
        return browser
        .executeScript(() => {
          window.component.clearAttribute(
            window.uic.tree[0].children[0],
            window.uic.tree[0].children[0].values[0]
          );
        });
      })
      .then(() => {
        return flows
        .getCheckboxFor(uic.tree[0].children[0].values[0].name)
        .getAttribute('class')
        .then((classes) => {
          expect(classes).to.not.contain(checkedClass);
        });
      });
    });
  });
});
