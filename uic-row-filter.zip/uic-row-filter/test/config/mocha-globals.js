/* eslint no-unused-vars: 0 */
var global = window,
  logLevel;

// Executes once before the first describe.
before(function() {
  logLevel = window.log.getLevel();

  // Set minimum log level
  window.log.setLevel(window.log.levels.SILENT);
});

// Executes once after all the describes.
after(function() {
  window.log.setLevel(logLevel);
});
