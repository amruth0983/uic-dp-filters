// Get specific browser configuration.
exports.config = require('./protractor.conf.js')('firefox');
