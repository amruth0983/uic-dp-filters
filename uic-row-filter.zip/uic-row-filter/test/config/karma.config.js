// Karma shared configuration
module.exports = function(options) {
  return {
    basePath: '../../',
    files: [
      'node_modules/datejs/build/date.js',
      'node_modules/jquery/dist/jquery.min.js',
      'node_modules/lodash/index.js',
      'node_modules/loglevel/dist/loglevel.min.js',
      'node_modules/angular/angular.min.js',
      'node_modules/event-emitter/event-emitter.js',
      'node_modules/ui-component/ui-component.js',
      'node_modules/angular-recursion/angular-recursion.min.js',
      'bower-components/jquery-ui/ui/minified/jquery-ui.min.js',
      'node_modules/angular-ui-slider/src/slider.js',
      'node_modules/uic-date-picker/dist/uic-date-picker.min.js',
      'node_modules/uic-date-range/dist/uic-date-range.js',
      'node_modules/angular-mocks/angular-mocks.js',
      'test/config/mocha-globals.js',
      `test/specs/${options.type}/**/*.spec.js`
    ],
    exclude: []
  };
};
