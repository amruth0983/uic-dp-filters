angular.module('reusableFilters',[
	'ngRoute',
	'reusableFilters.landing'
]);
